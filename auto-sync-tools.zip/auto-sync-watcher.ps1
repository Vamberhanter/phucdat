# Script tu dong sync khi co thay doi file
# Chay script nay mot lan, no se monitor va sync tu dong

param(
    [string]$sourcePath = "c:\Projects\Website\wordpress-theme",
    [string]$destPath = "C:\Users\Admin\Local Sites\test\app\public\wp-content\themes\test-theme",
    [int]$syncDelay = 2  # giay cho doi truoc khi sync
)

Write-Host "=== AUTO SYNC WATCHER ===" -ForegroundColor Cyan
Write-Host "Script nay se monitor thay doi va tu dong sync!" -ForegroundColor Yellow
Write-Host ""
Write-Host "Nguon: $sourcePath" -ForegroundColor Green
Write-Host "Dich:  $destPath" -ForegroundColor Green
Write-Host "Delay: $syncDelay giay" -ForegroundColor Green
Write-Host ""
Write-Host "Nhan Ctrl+C de dung script" -ForegroundColor Yellow
Write-Host ""

# Kiem tra duong dan
if (-not (Test-Path $sourcePath)) {
    Write-Host "LOI: Khong tim thay thu muc nguon: $sourcePath" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $destPath)) {
    Write-Host "LOI: Khong tim thay thu muc dich: $destPath" -ForegroundColor Red
    Write-Host "Vui long chay setup-symbolic-link.ps1 truoc!" -ForegroundColor Yellow
    exit 1
}

# Tao FileSystemWatcher
$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = $sourcePath
$watcher.IncludeSubdirectories = $true
$watcher.EnableRaisingEvents = $true

# Loai file can monitor
$watcher.Filter = "*.*"
$watcher.NotifyFilter = [System.IO.NotifyFilters]::LastWrite -bor
                     [System.IO.NotifyFilters]::FileName -bor
                     [System.IO.NotifyFilters]::DirectoryName

# Bien de tranh sync lien tiep
$lastSync = Get-Date
$pendingSync = $false

# Ham sync
function Sync-Files {
    param([string]$filePath)

    $global:lastSync = Get-Date
    $global:pendingSync = $true

    # Cho doi mot chut
    Start-Sleep -Seconds $syncDelay

    # Kiem tra xem co thay doi nao khac trong delay khong
    if ($global:pendingSync) {
        $global:pendingSync = $false

        Write-Host "$(Get-Date -Format 'HH:mm:ss') | Dang sync..." -ForegroundColor Yellow -NoNewline

        try {
            # Copy file don le thay vi copy ca thu muc
            $relativePath = $filePath.Replace($sourcePath, "").TrimStart("\")
            $destFile = Join-Path $destPath $relativePath

            # Tao thu muc cha neu can
            $destDir = Split-Path $destFile -Parent
            if (-not (Test-Path $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }

            # Copy file
            Copy-Item -Path $filePath -Destination $destFile -Force

            Write-Host " OK | $relativePath" -ForegroundColor Green
        } catch {
            Write-Host " LOI | $relativePath" -ForegroundColor Red
        }
    }
}

# Event handlers
$action = {
    $filePath = $Event.SourceEventArgs.FullPath
    $changeType = $Event.SourceEventArgs.ChangeType

    # Bo qua cac file tam thoi va cache
    if ($filePath -match '\.(tmp|temp|cache)$' -or
        $filePath -match '\\\..*' -or
        $filePath -match '\\node_modules\\' -or
        $filePath -match '\\\.git\\') {
        return
    }

    # Chi sync file thuc, khong phai thu muc
    if ((Get-Item $filePath) -is [System.IO.FileInfo]) {
        Sync-Files -filePath $filePath
    }
}

# Dang ky events
Register-ObjectEvent $watcher "Created" $action -SourceIdentifier "FileCreated"
Register-ObjectEvent $watcher "Changed" $action -SourceIdentifier "FileChanged"
Register-ObjectEvent $watcher "Renamed" $action -SourceIdentifier "FileRenamed"
Register-ObjectEvent $watcher "Deleted" $action -SourceIdentifier "FileDeleted"

# Hien thi thong tin
Write-Host "Dang monitor thay doi file..." -ForegroundColor Green
Write-Host "Nhan Ctrl+C de dung" -ForegroundColor Yellow
Write-Host ""

# Cho script chay lien tuc
try {
    while ($true) {
        Start-Sleep -Seconds 1
    }
} finally {
    # Cleanup
    Unregister-Event -SourceIdentifier "FileCreated"
    Unregister-Event -SourceIdentifier "FileChanged"
    Unregister-Event -SourceIdentifier "FileRenamed"
    Unregister-Event -SourceIdentifier "FileDeleted"

    Write-Host ""
    Write-Host "Da dung monitor!" -ForegroundColor Yellow
}