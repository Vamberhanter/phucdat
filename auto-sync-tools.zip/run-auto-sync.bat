@echo off
REM Script chay tu dong sync - Chon cach thich hop

echo ========================================
echo    TU DONG SYNC WORDPRESS THEME
echo ========================================
echo.
echo Chon cach sync tu dong:
echo.
echo [1] Symbolic Link (Tu dong hoan toan - Khuyen nghi)
echo [2] File Watcher (Tu dong khi co thay doi)
echo [3] Manual Sync (Cach cu)
echo.
set /p choice="Nhap lua chon (1-3): "

if "%choice%"=="1" goto symbolic
if "%choice%"=="2" goto watcher
if "%choice%"=="3" goto manual
goto end

:symbolic
echo.
echo === CAI DAT SYMBOLIC LINK ===
echo Script se tao lien ket tu dong.
echo Vui long dong WordPress Local truoc khi tiep tuc!
echo.
pause
powershell -ExecutionPolicy Bypass -File "%~dp0setup-symbolic-link.ps1"
goto end

:watcher
echo.
echo === KHOI DONG FILE WATCHER ===
echo Script se monitor va tu dong sync.
echo Nhan Ctrl+C de dung.
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0auto-sync-watcher.ps1"
goto end

:manual
echo.
echo === MANUAL SYNC ===
echo Dang sync code thu cong...
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0sync-to-local.ps1"
goto end

:end
echo.
echo Hoan thanh!
pause