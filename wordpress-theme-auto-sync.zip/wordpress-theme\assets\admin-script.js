jQuery(document).ready(function($) {
    // Media Uploader for Hình ảnh phụ
    var mediaUploader;
    
    $('#upload_hinh_anh_phu').on('click', function(e) {
        e.preventDefault();
        
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        
        mediaUploader = wp.media({
            title: 'Chọn hình ảnh phụ',
            button: {
                text: 'Sử dụng hình ảnh này'
            },
            multiple: false,
            library: {
                type: 'image'
            }
        });
        
        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#hinh_anh_phu').val(attachment.id);
            
            // Show preview
            var thumbUrl = attachment.url;
            if (attachment.sizes && attachment.sizes.thumbnail && attachment.sizes.thumbnail.url) {
                thumbUrl = attachment.sizes.thumbnail.url;
            }
            var previewHtml = '<div style="margin-top: 10px;" class="hinh-anh-phu-preview">';
            previewHtml += '<img src="' + thumbUrl + '" style="max-width: 150px; height: auto; border: 1px solid #ddd; padding: 5px;" />';
            previewHtml += '<p style="margin-top: 5px; color: #666; font-size: 12px;">ID: ' + attachment.id + '</p>';
            previewHtml += '</div>';
            
            // Remove old preview if exists
            $('.hinh-anh-phu-preview').remove();
            $('#hinh_anh_phu').after(previewHtml);
        });
        
        mediaUploader.open();
    });

    // Media uploader for gallery images (multiple)
    var galleryUploader;

    $('#upload_gallery_images').on('click', function(e) {
        e.preventDefault();

        if (galleryUploader) {
            galleryUploader.open();
            return;
        }

        galleryUploader = wp.media({
            title: 'Chọn nhiều hình cho thư viện',
            button: {
                text: 'Sử dụng các hình này'
            },
            multiple: true,
            library: {
                type: 'image'
            }
        });

        galleryUploader.on('select', function() {
            var selection   = galleryUploader.state().get('selection').toJSON();
            var ids         = [];
            var previewHtml = '';

            selection.forEach(function(attachment) {
                ids.push(attachment.id);
                var thumbUrl = attachment.url;
                if (attachment.sizes && attachment.sizes.thumbnail && attachment.sizes.thumbnail.url) {
                    thumbUrl = attachment.sizes.thumbnail.url;
                }
                previewHtml += '<div><img src="' + thumbUrl + '" style="max-width: 80px; height: auto; border:1px solid #ddd; padding:3px; background:#fff;" /></div>';
            });

            $('#gallery_images').val(ids.join(','));
            $('#gallery_images_preview').html(previewHtml);
        });

        galleryUploader.open();
    });
    
    // Populate Quick Edit fields
    var $inlineEditor = $('#inline-edit');
    var $bulkEditor = $('#bulk-edit');
    
    // Quick Edit
    $inlineEditor.on('click', '.editinline', function() {
        var $row = $(this).closest('tr');
        var postId = $row.attr('id').replace('post-', '');
        
        var nganh_hang = $row.find('.column-nganh_hang').text().trim();
        var khu_vuc = $row.find('.column-khu_vuc').text().trim();
        
        $inlineEditor.find('input[name="nganh_hang"]').val(nganh_hang);
        $inlineEditor.find('input[name="khu_vuc"]').val(khu_vuc);
    });
    
    // Bulk Edit - Add fields to form
    if ($bulkEditor.length) {
        $bulkEditor.find('.inline-edit-col-right').prepend(
            '<div class="inline-edit-col">' +
            '<div class="inline-edit-group wp-clearfix">' +
            '<label class="inline-edit-status alignleft">' +
            '<span class="title">Ngành hàng</span>' +
            '<input type="text" name="_nganh_hang" value="" />' +
            '</label>' +
            '</div>' +
            '<div class="inline-edit-group wp-clearfix">' +
            '<label class="inline-edit-status alignleft">' +
            '<span class="title">Khu vực</span>' +
            '<input type="text" name="_khu_vuc" value="" />' +
            '</label>' +
            '</div>' +
            '</div>'
        );
    }
});
