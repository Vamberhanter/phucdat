<?php
/**
 * Functions and definitions for Cộng đồng Doanh nhân Trí tuệ Việt Nam Theme
 */

// Enqueue styles and scripts
function dnttvn_enqueue_styles() {
    wp_enqueue_style('dnttvn-main-style', get_template_directory_uri() . '/assets/style-gioi-thieu.css', array(), '1.0.0');
    wp_enqueue_script('dnttvn-main-script', get_template_directory_uri() . '/assets/script.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'dnttvn_enqueue_styles');

// Register Custom Post Type: Tin tức
function dnttvn_register_tin_tuc_post_type() {
    $labels = array(
        'name'                  => 'Tin tức',
        'singular_name'         => 'Tin tức',
        'menu_name'             => 'Tin tức',
        'name_admin_bar'        => 'Tin tức',
        'archives'              => 'Danh sách Tin tức',
        'attributes'            => 'Thuộc tính Tin tức',
        'parent_item_colon'     => 'Tin tức cha:',
        'all_items'             => 'Tất cả Tin tức',
        'add_new_item'          => 'Thêm Tin tức mới',
        'add_new'               => 'Thêm mới',
        'new_item'              => 'Tin tức mới',
        'edit_item'             => 'Chỉnh sửa Tin tức',
        'update_item'           => 'Cập nhật Tin tức',
        'view_item'             => 'Xem Tin tức',
        'view_items'            => 'Xem Tin tức',
        'search_items'          => 'Tìm kiếm Tin tức',
        'not_found'             => 'Không tìm thấy',
        'not_found_in_trash'    => 'Không tìm thấy trong thùng rác',
        'featured_image'        => 'Hình ảnh đại diện',
        'set_featured_image'    => 'Đặt hình ảnh đại diện',
        'remove_featured_image' => 'Xóa hình ảnh đại diện',
        'use_featured_image'    => 'Sử dụng làm hình ảnh đại diện',
        'insert_into_item'      => 'Chèn vào Tin tức',
        'uploaded_to_this_item' => 'Tải lên Tin tức này',
        'items_list'            => 'Danh sách Tin tức',
        'items_list_navigation' => 'Điều hướng danh sách Tin tức',
        'filter_items_list'     => 'Lọc danh sách Tin tức',
    );
    $args = array(
        'label'                 => 'Tin tức',
        'description'           => 'Quản lý tin tức của Cộng đồng',
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'page-attributes'),
        'taxonomies'            => array('category', 'post_tag'),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-megaphone',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type('tin_tuc', $args);
}
add_action('init', 'dnttvn_register_tin_tuc_post_type', 0);

// Add custom meta boxes for Tin tức
function dnttvn_add_tin_tuc_meta_boxes() {
    add_meta_box(
        'tin_tuc_details',
        'Thông tin Tin tức',
        'dnttvn_tin_tuc_meta_box_callback',
        'tin_tuc',
        'normal',
        'high'
    );
    
    add_meta_box(
        'tin_tuc_author_info',
        'Thông tin Tác giả & Nguồn',
        'dnttvn_tin_tuc_author_meta_box_callback',
        'tin_tuc',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'dnttvn_add_tin_tuc_meta_boxes');

// Meta box callback for Tin tức details
function dnttvn_tin_tuc_meta_box_callback($post) {
    wp_nonce_field('dnttvn_save_tin_tuc_meta', 'dnttvn_tin_tuc_meta_nonce');
    
    $nguon = get_post_meta($post->ID, '_tin_tuc_nguon', true);
    $tac_gia = get_post_meta($post->ID, '_tin_tuc_tac_gia', true);
    $ngay_dang = get_post_meta($post->ID, '_tin_tuc_ngay_dang', true);
    $noi_bat = get_post_meta($post->ID, '_tin_tuc_noi_bat', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th><label for="tin_tuc_tac_gia">Tác giả</label></th>
            <td>
                <input type="text" id="tin_tuc_tac_gia" name="tin_tuc_tac_gia" value="<?php echo esc_attr($tac_gia); ?>" class="regular-text" />
                <p class="description">Tên tác giả viết bài (nếu có)</p>
            </td>
        </tr>
        <tr>
            <th><label for="tin_tuc_nguon">Nguồn</label></th>
            <td>
                <input type="url" id="tin_tuc_nguon" name="tin_tuc_nguon" value="<?php echo esc_url($nguon); ?>" class="regular-text" placeholder="https://..." />
                <p class="description">Link nguồn bài viết (nếu lấy từ nơi khác)</p>
            </td>
        </tr>
        <tr>
            <th><label for="tin_tuc_ngay_dang">Ngày đăng</label></th>
            <td>
                <input type="date" id="tin_tuc_ngay_dang" name="tin_tuc_ngay_dang" value="<?php echo esc_attr($ngay_dang); ?>" class="regular-text" />
                <p class="description">Ngày đăng tin (để trống sẽ dùng ngày hiện tại)</p>
            </td>
        </tr>
        <tr>
            <th><label for="tin_tuc_noi_bat">Tin nổi bật</label></th>
            <td>
                <label>
                    <input type="checkbox" id="tin_tuc_noi_bat" name="tin_tuc_noi_bat" value="1" <?php checked($noi_bat, '1'); ?> />
                    Đánh dấu tin này là tin nổi bật
                </label>
                <p class="description">Tin nổi bật sẽ được hiển thị ưu tiên trên trang chủ</p>
            </td>
        </tr>
    </table>
    <?php
}

// Meta box callback for Author info (Sidebar)
function dnttvn_tin_tuc_author_meta_box_callback($post) {
    $tac_gia = get_post_meta($post->ID, '_tin_tuc_tac_gia', true);
    $nguon = get_post_meta($post->ID, '_tin_tuc_nguon', true);
    ?>
    <div style="padding: 10px 0;">
        <p><strong>Hướng dẫn:</strong></p>
        <ul style="margin-left: 20px; margin-top: 10px;">
            <li>Nhập <strong>Tiêu đề</strong> rõ ràng, hấp dẫn</li>
            <li>Viết <strong>Nội dung</strong> đầy đủ, có format đẹp</li>
            <li>Thêm <strong>Excerpt</strong> (tóm tắt) để hiển thị ở trang chủ</li>
            <li>Chọn <strong>Featured Image</strong> (hình ảnh đại diện)</li>
            <li>Chọn <strong>Categories</strong> và <strong>Tags</strong> phù hợp</li>
        </ul>
        <?php if ($tac_gia) : ?>
            <p style="margin-top: 15px;"><strong>Tác giả:</strong> <?php echo esc_html($tac_gia); ?></p>
        <?php endif; ?>
        <?php if ($nguon) : ?>
            <p><strong>Nguồn:</strong> <a href="<?php echo esc_url($nguon); ?>" target="_blank">Xem nguồn</a></p>
        <?php endif; ?>
    </div>
    <?php
}

// Save Tin tức meta box data
function dnttvn_save_tin_tuc_meta($post_id) {
    if (!isset($_POST['dnttvn_tin_tuc_meta_nonce'])) {
        return;
    }
    
    if (!wp_verify_nonce($_POST['dnttvn_tin_tuc_meta_nonce'], 'dnttvn_save_tin_tuc_meta')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (get_post_type($post_id) != 'tin_tuc') {
        return;
    }
    
    if (isset($_POST['tin_tuc_tac_gia'])) {
        update_post_meta($post_id, '_tin_tuc_tac_gia', sanitize_text_field($_POST['tin_tuc_tac_gia']));
    }
    
    if (isset($_POST['tin_tuc_nguon'])) {
        update_post_meta($post_id, '_tin_tuc_nguon', esc_url_raw($_POST['tin_tuc_nguon']));
    }
    
    if (isset($_POST['tin_tuc_ngay_dang'])) {
        update_post_meta($post_id, '_tin_tuc_ngay_dang', sanitize_text_field($_POST['tin_tuc_ngay_dang']));
    }
    
    if (isset($_POST['tin_tuc_noi_bat'])) {
        update_post_meta($post_id, '_tin_tuc_noi_bat', '1');
    } else {
        delete_post_meta($post_id, '_tin_tuc_noi_bat');
    }
}
add_action('save_post', 'dnttvn_save_tin_tuc_meta');

// Enhance editor for Tin tức
function dnttvn_enhance_tin_tuc_editor($settings, $editor_id) {
    if ($editor_id == 'content' && get_current_screen()->post_type == 'tin_tuc') {
        // Enable full toolbar
        $settings['toolbar1'] = 'bold,italic,underline,strikethrough,bullist,numlist,blockquote,hr,alignleft,aligncenter,alignright,link,unlink,wp_more,spellchecker,fullscreen,wp_adv';
        $settings['toolbar2'] = 'formatselect,fontselect,fontsizeselect,forecolor,backcolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help';
        
        // Enable more features
        $settings['wordpress_adv_hidden'] = false;
        $settings['paste_as_text'] = false;
        $settings['wpautop'] = true;
        $settings['media_buttons'] = true;
    }
    return $settings;
}
add_filter('tiny_mce_before_init', 'dnttvn_enhance_tin_tuc_editor', 10, 2);

// Add admin styles for Tin tức editor
function dnttvn_tin_tuc_admin_styles() {
    global $post_type;
    if ($post_type == 'tin_tuc') {
        ?>
        <style>
            /* Improve editor area */
            #tin_tuc_details .inside {
                padding: 15px;
            }
            
            #tin_tuc_details .form-table th {
                width: 150px;
                font-weight: 600;
            }
            
            #tin_tuc_author_info .inside {
                background: #f9f9f9;
                border-left: 4px solid #667eea;
            }
            
            /* Highlight important fields */
            .postbox#tin_tuc_details {
                border-left: 4px solid #667eea;
            }
            
            /* Better form styling */
            #tin_tuc_details input[type="text"],
            #tin_tuc_details input[type="url"],
            #tin_tuc_details input[type="date"] {
                width: 100%;
                max-width: 500px;
            }
            
            /* Checkbox styling */
            #tin_tuc_details input[type="checkbox"] {
                margin-right: 8px;
            }
        </style>
        <?php
    }
}
add_action('admin_head', 'dnttvn_tin_tuc_admin_styles');

// Register Custom Post Type: Doanh nghiệp
function dnttvn_register_doanh_nghiep_post_type() {
    $labels = array(
        'name'                  => 'Doanh nghiệp',
        'singular_name'         => 'Doanh nghiệp',
        'menu_name'             => 'Doanh nghiệp',
        'name_admin_bar'        => 'Doanh nghiệp',
        'archives'              => 'Danh sách Doanh nghiệp',
        'attributes'            => 'Thuộc tính Doanh nghiệp',
        'parent_item_colon'     => 'Doanh nghiệp cha:',
        'all_items'             => 'Tất cả Doanh nghiệp',
        'add_new_item'          => 'Thêm Doanh nghiệp mới',
        'add_new'               => 'Thêm mới',
        'new_item'              => 'Doanh nghiệp mới',
        'edit_item'             => 'Chỉnh sửa Doanh nghiệp',
        'update_item'           => 'Cập nhật Doanh nghiệp',
        'view_item'             => 'Xem Doanh nghiệp',
        'view_items'            => 'Xem Doanh nghiệp',
        'search_items'          => 'Tìm kiếm Doanh nghiệp',
        'not_found'             => 'Không tìm thấy',
        'not_found_in_trash'    => 'Không tìm thấy trong thùng rác',
        'featured_image'        => 'Hình ảnh đại diện',
        'set_featured_image'    => 'Đặt hình ảnh đại diện',
        'remove_featured_image' => 'Xóa hình ảnh đại diện',
        'use_featured_image'    => 'Sử dụng làm hình ảnh đại diện',
        'insert_into_item'      => 'Chèn vào Doanh nghiệp',
        'uploaded_to_this_item' => 'Tải lên Doanh nghiệp này',
        'items_list'            => 'Danh sách Doanh nghiệp',
        'items_list_navigation' => 'Điều hướng danh sách Doanh nghiệp',
        'filter_items_list'     => 'Lọc danh sách Doanh nghiệp',
    );
    $args = array(
        'label'                 => 'Doanh nghiệp',
        'description'           => 'Quản lý danh sách doanh nghiệp',
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'page-attributes'),
        'taxonomies'            => array('nganh_hang', 'khu_vuc'),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 6,
        'menu_icon'             => 'dashicons-building',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type('doanh_nghiep', $args);
}
add_action('init', 'dnttvn_register_doanh_nghiep_post_type', 0);

// Register Custom Taxonomies for Doanh nghiệp
function dnttvn_register_doanh_nghiep_taxonomies() {
    // Taxonomy: Ngành hàng
    register_taxonomy('nganh_hang', array('doanh_nghiep'), array(
        'hierarchical'          => true,
        'labels'                => array(
            'name'              => 'Ngành hàng',
            'singular_name'     => 'Ngành hàng',
            'search_items'      => 'Tìm kiếm Ngành hàng',
            'all_items'         => 'Tất cả Ngành hàng',
            'parent_item'       => 'Ngành hàng cha',
            'parent_item_colon' => 'Ngành hàng cha:',
            'edit_item'         => 'Chỉnh sửa Ngành hàng',
            'update_item'       => 'Cập nhật Ngành hàng',
            'add_new_item'      => 'Thêm Ngành hàng mới',
            'new_item_name'     => 'Tên Ngành hàng mới',
            'menu_name'         => 'Ngành hàng',
        ),
        'show_ui'               => true,
        'show_admin_column'     => true,
        'query_var'             => true,
        'rewrite'               => array('slug' => 'nganh-hang'),
        'show_in_rest'          => true,
    ));

    // Taxonomy: Khu vực
    register_taxonomy('khu_vuc', array('doanh_nghiep'), array(
        'hierarchical'          => true,
        'labels'                => array(
            'name'              => 'Khu vực',
            'singular_name'     => 'Khu vực',
            'search_items'      => 'Tìm kiếm Khu vực',
            'all_items'         => 'Tất cả Khu vực',
            'parent_item'       => 'Khu vực cha',
            'parent_item_colon' => 'Khu vực cha:',
            'edit_item'         => 'Chỉnh sửa Khu vực',
            'update_item'       => 'Cập nhật Khu vực',
            'add_new_item'      => 'Thêm Khu vực mới',
            'new_item_name'     => 'Tên Khu vực mới',
            'menu_name'         => 'Khu vực',
        ),
        'show_ui'               => true,
        'show_admin_column'     => true,
        'query_var'             => true,
        'rewrite'               => array('slug' => 'khu-vuc'),
        'show_in_rest'          => true,
    ));
}
add_action('init', 'dnttvn_register_doanh_nghiep_taxonomies', 0);

// ============================================
// CUSTOM POST TYPE: CỘNG ĐỒNG
// ============================================

// Register Custom Post Type: Cộng đồng
function dnttvn_register_cong_dong_post_type() {
    $labels = array(
        'name'                  => 'Cộng đồng',
        'singular_name'         => 'Bài Cộng đồng',
        'menu_name'             => 'Cộng đồng',
        'name_admin_bar'        => 'Bài Cộng đồng',
        'archives'              => 'Danh sách Cộng đồng',
        'attributes'            => 'Thuộc tính',
        'parent_item_colon'     => 'Bài cha:',
        'all_items'             => 'Tất cả bài',
        'add_new_item'          => 'Thêm bài mới',
        'add_new'               => 'Thêm mới',
        'new_item'              => 'Bài mới',
        'edit_item'             => 'Chỉnh sửa bài',
        'update_item'           => 'Cập nhật bài',
        'view_item'             => 'Xem bài',
        'view_items'            => 'Xem bài',
        'search_items'          => 'Tìm kiếm bài',
        'not_found'             => 'Không tìm thấy',
        'not_found_in_trash'    => 'Không tìm thấy trong thùng rác',
        'featured_image'        => 'Hình ảnh đại diện',
        'set_featured_image'    => 'Đặt hình ảnh đại diện',
        'remove_featured_image' => 'Xóa hình ảnh đại diện',
        'use_featured_image'    => 'Sử dụng làm hình ảnh đại diện',
        'insert_into_item'      => 'Chèn vào bài',
        'uploaded_to_this_item' => 'Tải lên bài này',
        'items_list'            => 'Danh sách bài',
        'items_list_navigation' => 'Điều hướng danh sách',
        'filter_items_list'     => 'Lọc danh sách',
    );
    $args = array(
        'label'                 => 'Cộng đồng',
        'description'           => 'Quản lý bài viết về cộng đồng',
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'page-attributes'),
        'taxonomies'            => array('category', 'post_tag'),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 7,
        'menu_icon'             => 'dashicons-groups',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type('cong_dong', $args);
}
add_action('init', 'dnttvn_register_cong_dong_post_type', 0);

// Add custom meta boxes for Cộng đồng
function dnttvn_add_cong_dong_meta_boxes() {
    add_meta_box(
        'cong_dong_details',
        'Thông tin Bài Cộng đồng',
        'dnttvn_cong_dong_meta_box_callback',
        'cong_dong',
        'normal',
        'high'
    );
    
    add_meta_box(
        'cong_dong_schedule_info',
        'Lên lịch đăng bài',
        'dnttvn_cong_dong_schedule_meta_box_callback',
        'cong_dong',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'dnttvn_add_cong_dong_meta_boxes');

// Meta box callback for Cộng đồng details
function dnttvn_cong_dong_meta_box_callback($post) {
    wp_nonce_field('dnttvn_save_cong_dong_meta', 'dnttvn_cong_dong_meta_nonce');
    
    $noi_bat = get_post_meta($post->ID, '_cong_dong_noi_bat', true);
    $mo_ta_ngan = get_post_meta($post->ID, '_cong_dong_mo_ta_ngan', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th><label for="cong_dong_mo_ta_ngan">Mô tả ngắn</label></th>
            <td>
                <textarea id="cong_dong_mo_ta_ngan" name="cong_dong_mo_ta_ngan" rows="3" class="large-text"><?php echo esc_textarea($mo_ta_ngan); ?></textarea>
                <p class="description">Mô tả ngắn gọn sẽ hiển thị trong danh sách (nếu không nhập excerpt)</p>
            </td>
        </tr>
        <tr>
            <th><label for="cong_dong_noi_bat">Bài nổi bật</label></th>
            <td>
                <label>
                    <input type="checkbox" id="cong_dong_noi_bat" name="cong_dong_noi_bat" value="1" <?php checked($noi_bat, '1'); ?> />
                    Đánh dấu bài này là bài nổi bật
                </label>
                <p class="description">Bài nổi bật sẽ được hiển thị ưu tiên</p>
            </td>
        </tr>
    </table>
    <?php
}

// Meta box callback for Schedule info (Sidebar)
function dnttvn_cong_dong_schedule_meta_box_callback($post) {
    $ngay_dang = get_post_meta($post->ID, '_cong_dong_ngay_dang', true);
    ?>
    <div style="padding: 10px 0;">
        <p><strong>Lên lịch đăng bài:</strong></p>
        <label for="cong_dong_ngay_dang">Ngày đăng:</label>
        <input type="date" id="cong_dong_ngay_dang" name="cong_dong_ngay_dang" value="<?php echo esc_attr($ngay_dang); ?>" style="width: 100%; margin-top: 5px;" />
        <p class="description" style="margin-top: 10px;">Để trống sẽ dùng ngày hiện tại. Hoặc sử dụng "Publish" date của WordPress.</p>
        
        <hr style="margin: 15px 0;">
        
        <p><strong>Hướng dẫn:</strong></p>
        <ul style="margin-left: 20px; margin-top: 10px;">
            <li>Nhập <strong>Tiêu đề</strong> rõ ràng</li>
            <li>Viết <strong>Nội dung</strong> đầy đủ</li>
            <li>Thêm <strong>Mô tả ngắn</strong> hoặc <strong>Excerpt</strong></li>
            <li>Chọn <strong>Hình ảnh đại diện</strong> (nếu có)</li>
            <li>Đặt <strong>Order</strong> (Page Attributes) để sắp xếp thứ tự</li>
        </ul>
    </div>
    <?php
}

// Save Cộng đồng meta box data
function dnttvn_save_cong_dong_meta($post_id) {
    if (!isset($_POST['dnttvn_cong_dong_meta_nonce'])) {
        return;
    }
    
    if (!wp_verify_nonce($_POST['dnttvn_cong_dong_meta_nonce'], 'dnttvn_save_cong_dong_meta')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (get_post_type($post_id) != 'cong_dong') {
        return;
    }
    
    if (isset($_POST['cong_dong_mo_ta_ngan'])) {
        update_post_meta($post_id, '_cong_dong_mo_ta_ngan', sanitize_textarea_field($_POST['cong_dong_mo_ta_ngan']));
    }
    
    if (isset($_POST['cong_dong_ngay_dang'])) {
        update_post_meta($post_id, '_cong_dong_ngay_dang', sanitize_text_field($_POST['cong_dong_ngay_dang']));
    }
    
    if (isset($_POST['cong_dong_noi_bat'])) {
        update_post_meta($post_id, '_cong_dong_noi_bat', '1');
    } else {
        delete_post_meta($post_id, '_cong_dong_noi_bat');
    }
}
add_action('save_post', 'dnttvn_save_cong_dong_meta');

// Add Admin Columns for Cộng đồng
function dnttvn_add_cong_dong_admin_columns($columns) {
    $new_columns = array();
    $new_columns['cb'] = $columns['cb'];
    $new_columns['title'] = $columns['title'];
    $new_columns['menu_order'] = 'Thứ tự';
    $new_columns['noi_bat'] = 'Nổi bật';
    $new_columns['date'] = $columns['date'];
    return $new_columns;
}
add_filter('manage_cong_dong_posts_columns', 'dnttvn_add_cong_dong_admin_columns');

// Populate Admin Columns for Cộng đồng
function dnttvn_populate_cong_dong_admin_columns($column, $post_id) {
    switch ($column) {
        case 'menu_order':
            $menu_order = get_post($post_id)->menu_order;
            echo '<strong>' . esc_html($menu_order) . '</strong>';
            break;
        case 'noi_bat':
            $noi_bat = get_post_meta($post_id, '_cong_dong_noi_bat', true);
            if ($noi_bat == '1') {
                echo '<span style="color: #ff9800; font-weight: bold;">⭐ Nổi bật</span>';
            } else {
                echo '—';
            }
            break;
    }
}
add_action('manage_cong_dong_posts_custom_column', 'dnttvn_populate_cong_dong_admin_columns', 10, 2);

// Make Cộng đồng Columns Sortable
function dnttvn_make_cong_dong_columns_sortable($columns) {
    $columns['menu_order'] = 'menu_order';
    $columns['noi_bat'] = 'noi_bat';
    return $columns;
}
add_filter('manage_edit-cong_dong_sortable_columns', 'dnttvn_make_cong_dong_columns_sortable');

// Handle Cộng đồng Sorting
function dnttvn_handle_cong_dong_sorting($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $orderby = $query->get('orderby');
    if ($orderby == 'menu_order' && get_query_var('post_type') == 'cong_dong') {
        $query->set('orderby', 'menu_order');
        $query->set('order', 'ASC');
    } elseif ($orderby == 'noi_bat' && get_query_var('post_type') == 'cong_dong') {
        $query->set('meta_key', '_cong_dong_noi_bat');
        $query->set('orderby', 'meta_value date');
        $query->set('order', 'DESC');
    }
}
add_action('pre_get_posts', 'dnttvn_handle_cong_dong_sorting');

// Add admin styles for Cộng đồng editor
function dnttvn_cong_dong_admin_styles() {
    global $post_type;
    if ($post_type == 'cong_dong') {
        ?>
        <style>
            #cong_dong_details .inside {
                padding: 15px;
            }
            
            #cong_dong_details .form-table th {
                width: 150px;
                font-weight: 600;
            }
            
            #cong_dong_schedule_info .inside {
                background: #f9f9f9;
                border-left: 4px solid #2271b1;
            }
            
            .postbox#cong_dong_details {
                border-left: 4px solid #2271b1;
            }
            
            #cong_dong_details input[type="text"],
            #cong_dong_details textarea {
                width: 100%;
            }
            
            #cong_dong_details input[type="checkbox"] {
                margin-right: 8px;
            }
        </style>
        <?php
    }
}
add_action('admin_head', 'dnttvn_cong_dong_admin_styles');

// Add custom meta boxes for Doanh nghiệp
function dnttvn_add_doanh_nghiep_meta_boxes() {
    add_meta_box(
        'doanh_nghiep_details',
        'Thông tin Doanh nghiệp',
        'dnttvn_doanh_nghiep_meta_box_callback',
        'doanh_nghiep',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'dnttvn_add_doanh_nghiep_meta_boxes');

// Meta box callback
function dnttvn_doanh_nghiep_meta_box_callback($post) {
    wp_nonce_field('dnttvn_save_doanh_nghiep_meta', 'dnttvn_doanh_nghiep_meta_nonce');
    
    $nganh_hang    = get_post_meta($post->ID, '_nganh_hang', true);
    $khu_vuc       = get_post_meta($post->ID, '_khu_vuc', true);
    $hinh_anh_phu  = get_post_meta($post->ID, '_hinh_anh_phu', true);
    $gallery_value = get_post_meta($post->ID, '_gallery_images', true); // comma-separated IDs
    $dia_chi       = get_post_meta($post->ID, '_dia_chi', true);
    $dien_thoai    = get_post_meta($post->ID, '_dien_thoai', true);
    $email_lh      = get_post_meta($post->ID, '_email_lien_he', true);
    $website_dn    = get_post_meta($post->ID, '_website_doanh_nghiep', true);
    $thong_tin_bs  = get_post_meta($post->ID, '_thong_tin_bo_sung', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th><label for="nganh_hang">Ngành hàng</label></th>
            <td>
                <input type="text" id="nganh_hang" name="nganh_hang" value="<?php echo esc_attr($nganh_hang); ?>" class="regular-text" />
                <p class="description">Ví dụ: Công nghệ, Tài chính, Bán lẻ...</p>
            </td>
        </tr>
        <tr>
            <th><label for="khu_vuc">Khu vực</label></th>
            <td>
                <input type="text" id="khu_vuc" name="khu_vuc" value="<?php echo esc_attr($khu_vuc); ?>" class="regular-text" />
                <p class="description">Ví dụ: Hà Nội, TP. Hồ Chí Minh, Đà Nẵng...</p>
            </td>
        </tr>
        <tr>
            <th><label for="dia_chi">Địa chỉ</label></th>
            <td>
                <input type="text" id="dia_chi" name="dia_chi" value="<?php echo esc_attr($dia_chi); ?>" class="regular-text" />
                <p class="description">Ví dụ: Số nhà, đường, quận/huyện, thành phố.</p>
            </td>
        </tr>
        <tr>
            <th><label for="dien_thoai">Điện thoại</label></th>
            <td>
                <input type="text" id="dien_thoai" name="dien_thoai" value="<?php echo esc_attr($dien_thoai); ?>" class="regular-text" />
                <p class="description">Ví dụ: 0909 000 000.</p>
            </td>
        </tr>
        <tr>
            <th><label for="email_lien_he">Email liên hệ</label></th>
            <td>
                <input type="email" id="email_lien_he" name="email_lien_he" value="<?php echo esc_attr($email_lh); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="website_doanh_nghiep">Website doanh nghiệp</label></th>
            <td>
                <input type="url" id="website_doanh_nghiep" name="website_doanh_nghiep" value="<?php echo esc_attr($website_dn); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="hinh_anh_phu">Hình ảnh phụ</label></th>
            <td>
                <input type="text" id="hinh_anh_phu" name="hinh_anh_phu" value="<?php echo esc_attr($hinh_anh_phu); ?>" class="regular-text" />
                <button type="button" class="button" id="upload_hinh_anh_phu">Chọn hình ảnh</button>
                <p class="description">
                    <strong>Lưu ý:</strong><br>
                    • <strong>Hình chính:</strong> Sử dụng "Featured Image" (Hình ảnh đại diện) ở sidebar bên phải - đây là logo/ảnh chính của doanh nghiệp<br>
                    • <strong>Hình ảnh phụ:</strong> Ảnh bổ sung hiển thị ở phần mô tả (có thể để trống). Nhập ID hoặc URL của hình ảnh, hoặc click "Chọn hình ảnh" để upload.
                </p>
                <?php if ($hinh_anh_phu) : ?>
                    <?php
                    $preview_id = is_numeric($hinh_anh_phu) ? absint($hinh_anh_phu) : attachment_url_to_postid($hinh_anh_phu);
                    if ($preview_id) {
                        echo '<div style="margin-top: 10px;">';
                        echo wp_get_attachment_image($preview_id, 'thumbnail');
                        echo '</div>';
                    } elseif (filter_var($hinh_anh_phu, FILTER_VALIDATE_URL)) {
                        echo '<div style="margin-top: 10px;"><img src="' . esc_url($hinh_anh_phu) . '" style="max-width: 150px; height: auto;" /></div>';
                    }
                    ?>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th><label for="gallery_images">Thư viện hình (nhiều hình)</label></th>
            <td>
                <input type="hidden" id="gallery_images" name="gallery_images" value="<?php echo esc_attr($gallery_value); ?>" />
                <button type="button" class="button" id="upload_gallery_images">Chọn nhiều hình</button>
                <p class="description">
                    Bạn có thể chọn nhiều hình để hiển thị dạng slide trong trang chi tiết Doanh nghiệp (mũi tên qua lại).
                </p>
                <div id="gallery_images_preview" style="margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap;">
                    <?php
                    if (!empty($gallery_value)) {
                        $ids = array_filter(array_map('absint', explode(',', $gallery_value)));
                        foreach ($ids as $img_id) {
                            $thumb = wp_get_attachment_image($img_id, 'thumbnail', false, array(
                                'style' => 'border:1px solid #ddd; padding:3px; background:#fff;'
                            ));
                            if ($thumb) {
                                echo '<div>' . $thumb . '</div>';
                            }
                        }
                    }
                    ?>
                </div>
            </td>
        </tr>
        <tr>
            <th><label for="thong_tin_bo_sung">Thông tin bổ sung</label></th>
            <td>
                <textarea id="thong_tin_bo_sung" name="thong_tin_bo_sung" rows="4" class="large-text"><?php echo esc_textarea($thong_tin_bs); ?></textarea>
                <p class="description">Thêm ghi chú, thông tin chi tiết khác về doanh nghiệp (ví dụ: giờ làm việc, chính sách, người liên hệ...).</p>
            </td>
        </tr>
    </table>
    <?php
}

// Save meta box data
function dnttvn_save_doanh_nghiep_meta($post_id) {
    if (!isset($_POST['dnttvn_doanh_nghiep_meta_nonce'])) {
        return;
    }
    
    if (!wp_verify_nonce($_POST['dnttvn_doanh_nghiep_meta_nonce'], 'dnttvn_save_doanh_nghiep_meta')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (isset($_POST['nganh_hang'])) {
        update_post_meta($post_id, '_nganh_hang', sanitize_text_field($_POST['nganh_hang']));
    }
    
    if (isset($_POST['khu_vuc'])) {
        update_post_meta($post_id, '_khu_vuc', sanitize_text_field($_POST['khu_vuc']));
    }
    
    if (isset($_POST['dia_chi'])) {
        update_post_meta($post_id, '_dia_chi', sanitize_text_field($_POST['dia_chi']));
    }

    if (isset($_POST['dien_thoai'])) {
        update_post_meta($post_id, '_dien_thoai', sanitize_text_field($_POST['dien_thoai']));
    }

    if (isset($_POST['email_lien_he'])) {
        update_post_meta($post_id, '_email_lien_he', sanitize_email($_POST['email_lien_he']));
    }

    if (isset($_POST['website_doanh_nghiep'])) {
        update_post_meta($post_id, '_website_doanh_nghiep', esc_url_raw($_POST['website_doanh_nghiep']));
    }
    
    if (isset($_POST['hinh_anh_phu'])) {
        update_post_meta($post_id, '_hinh_anh_phu', sanitize_text_field($_POST['hinh_anh_phu']));
    }

    if (isset($_POST['gallery_images'])) {
        $raw  = sanitize_text_field($_POST['gallery_images']);
        $ids  = array_filter(array_map('absint', explode(',', $raw)));
        $save = !empty($ids) ? implode(',', $ids) : '';
        update_post_meta($post_id, '_gallery_images', $save);
    }

    if (isset($_POST['thong_tin_bo_sung'])) {
        update_post_meta($post_id, '_thong_tin_bo_sung', wp_kses_post($_POST['thong_tin_bo_sung']));
    }
}
add_action('save_post', 'dnttvn_save_doanh_nghiep_meta');

// Theme support
function dnttvn_theme_setup() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    
    // Register navigation menu
    register_nav_menus(array(
        'primary' => 'Menu chính',
    ));
}
add_action('after_setup_theme', 'dnttvn_theme_setup');

// Auto-create "Danh sách Doanh nghiệp" page on theme activation
function dnttvn_create_doanh_nghiep_page() {
    // Check if page already exists with new slug
    $page_slug = 'danh-sach-doanh-nghiep';
    $existing_page = get_page_by_path($page_slug);
    
    // Also check old slug for migration
    if (!$existing_page) {
        $old_page = get_page_by_path('page-doanh-nghiep');
        if ($old_page) {
            // Update existing page slug
            wp_update_post(array(
                'ID' => $old_page->ID,
                'post_name' => $page_slug
            ));
            $existing_page = $old_page;
        }
    }
    
    if (!$existing_page) {
        // Create the page
        $page_data = array(
            'post_title'    => 'Danh sách Doanh nghiệp',
            'post_name'     => $page_slug,
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1,
            'page_template' => 'page-doanh-nghiep.php',
        );
        
        $page_id = wp_insert_post($page_data);
        
        // Set page template
        if ($page_id && !is_wp_error($page_id)) {
            update_post_meta($page_id, '_wp_page_template', 'page-doanh-nghiep.php');
        }
    } else {
        // Update existing page to use correct template and slug
        wp_update_post(array(
            'ID' => $existing_page->ID,
            'post_name' => $page_slug
        ));
        update_post_meta($existing_page->ID, '_wp_page_template', 'page-doanh-nghiep.php');
    }
}
add_action('after_switch_theme', 'dnttvn_create_doanh_nghiep_page');

// Auto-create "Cộng đồng" page on theme activation
function dnttvn_create_cong_dong_page() {
    $page_slug = 'cong-dong';
    $existing_page = get_page_by_path($page_slug);
    
    if (!$existing_page) {
        // Create the page
        $page_data = array(
            'post_title'    => 'Cộng đồng',
            'post_name'     => $page_slug,
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1,
            'page_template' => 'page-cong-dong.php',
        );
        
        $page_id = wp_insert_post($page_data);
        
        // Set page template
        if ($page_id && !is_wp_error($page_id)) {
            update_post_meta($page_id, '_wp_page_template', 'page-cong-dong.php');
        }
    } else {
        // Update existing page to use correct template
        update_post_meta($existing_page->ID, '_wp_page_template', 'page-cong-dong.php');
    }
}
add_action('after_switch_theme', 'dnttvn_create_cong_dong_page');

// Default menu fallback
function dnttvn_default_menu() {
    echo '<ul class="menu" id="mainMenu">';
    echo '<li><a href="' . esc_url(home_url()) . '">Trang chủ</a></li>';
    $tin_tuc_link = get_post_type_archive_link('tin_tuc');
    if ($tin_tuc_link) {
        echo '<li><a href="' . esc_url($tin_tuc_link) . '">Tin tức</a></li>';
    }
    $page_doanh_nghiep = get_page_by_path('danh-sach-doanh-nghiep');
    if (!$page_doanh_nghiep) {
        // Fallback to old slug
        $page_doanh_nghiep = get_page_by_path('page-doanh-nghiep');
    }
    if ($page_doanh_nghiep) {
        echo '<li><a href="' . esc_url(get_permalink($page_doanh_nghiep->ID)) . '">Danh sách Doanh nghiệp</a></li>';
    }
    echo '<li><a href="#">Giới thiệu</a></li>';
    echo '<li><a href="#">Liên hệ</a></li>';
    echo '</ul>';
}

// ============================================
// ADMIN MANAGEMENT FEATURES
// ============================================

// Add Admin Columns for Doanh nghiệp
function dnttvn_add_doanh_nghiep_admin_columns($columns) {
    $new_columns = array();
    $new_columns['cb'] = $columns['cb'];
    $new_columns['title'] = $columns['title'];
    $new_columns['menu_order'] = 'Thứ tự';
    $new_columns['nganh_hang'] = 'Ngành hàng';
    $new_columns['khu_vuc'] = 'Khu vực';
    $new_columns['nganh_hang_tax'] = 'Ngành hàng (Taxonomy)';
    $new_columns['khu_vuc_tax'] = 'Khu vực (Taxonomy)';
    $new_columns['date'] = $columns['date'];
    return $new_columns;
}
add_filter('manage_doanh_nghiep_posts_columns', 'dnttvn_add_doanh_nghiep_admin_columns');

// Populate Admin Columns for Doanh nghiệp
function dnttvn_populate_doanh_nghiep_admin_columns($column, $post_id) {
    switch ($column) {
        case 'menu_order':
            $menu_order = get_post($post_id)->menu_order;
            echo '<strong>' . esc_html($menu_order) . '</strong>';
            break;
        case 'nganh_hang':
            $nganh_hang = get_post_meta($post_id, '_nganh_hang', true);
            echo $nganh_hang ? esc_html($nganh_hang) : '—';
            break;
        case 'khu_vuc':
            $khu_vuc = get_post_meta($post_id, '_khu_vuc', true);
            echo $khu_vuc ? esc_html($khu_vuc) : '—';
            break;
        case 'nganh_hang_tax':
            $terms = get_the_terms($post_id, 'nganh_hang');
            if ($terms && !is_wp_error($terms)) {
                $term_names = array();
                foreach ($terms as $term) {
                    $term_names[] = $term->name;
                }
                echo implode(', ', $term_names);
            } else {
                echo '—';
            }
            break;
        case 'khu_vuc_tax':
            $terms = get_the_terms($post_id, 'khu_vuc');
            if ($terms && !is_wp_error($terms)) {
                $term_names = array();
                foreach ($terms as $term) {
                    $term_names[] = $term->name;
                }
                echo implode(', ', $term_names);
            } else {
                echo '—';
            }
            break;
    }
}
add_action('manage_doanh_nghiep_posts_custom_column', 'dnttvn_populate_doanh_nghiep_admin_columns', 10, 2);

// Make Admin Columns Sortable
function dnttvn_make_doanh_nghiep_columns_sortable($columns) {
    $columns['menu_order'] = 'menu_order';
    $columns['nganh_hang'] = 'nganh_hang';
    $columns['khu_vuc'] = 'khu_vuc';
    return $columns;
}
add_filter('manage_edit-doanh_nghiep_sortable_columns', 'dnttvn_make_doanh_nghiep_columns_sortable');

// Enable drag & drop sorting for Doanh nghiệp
function dnttvn_enable_doanh_nghiep_drag_drop() {
    global $typenow;
    if ($typenow == 'doanh_nghiep') {
        wp_enqueue_script('jquery-ui-sortable');
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('#the-list').sortable({
                items: 'tr',
                cursor: 'move',
                handle: '.column-title',
                placeholder: 'ui-sortable-placeholder',
                update: function(event, ui) {
                    var order = [];
                    $('#the-list tr').each(function() {
                        var postId = $(this).attr('id').replace('post-', '');
                        order.push(postId);
                    });

                    // Save new order via AJAX
                    $.post(ajaxurl, {
                        action: 'update_doanh_nghiep_order',
                        order: order,
                        nonce: '<?php echo wp_create_nonce('update_doanh_nghiep_order'); ?>'
                    });
                }
            });

            // Add drag handle styling
            $('#the-list .column-title').css('cursor', 'move');
        });
        </script>
        <style>
            #the-list tr.ui-sortable-placeholder {
                background: #f0f0f0;
                border: 2px dashed #ccc;
                visibility: visible !important;
            }
            #the-list tr.ui-sortable-helper {
                background: #fff;
                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            }
        </style>
        <?php
    }
}
add_action('admin_footer', 'dnttvn_enable_doanh_nghiep_drag_drop');

// AJAX handler for updating doanh nghiệp order
function dnttvn_update_doanh_nghiep_order() {
    if (!wp_verify_nonce($_POST['nonce'], 'update_doanh_nghiep_order')) {
        wp_die('Security check failed');
    }

    if (!current_user_can('edit_posts')) {
        wp_die('Insufficient permissions');
    }

    $order = $_POST['order'];
    $position = 1;

    foreach ($order as $post_id) {
        wp_update_post(array(
            'ID' => $post_id,
            'menu_order' => $position
        ));
        $position++;
    }

    wp_die();
}
add_action('wp_ajax_update_doanh_nghiep_order', 'dnttvn_update_doanh_nghiep_order');

// Handle Sorting
function dnttvn_handle_doanh_nghiep_sorting($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $orderby = $query->get('orderby');
    if ($orderby == 'menu_order') {
        $query->set('orderby', 'menu_order');
        $query->set('order', 'ASC');
    } elseif ($orderby == 'nganh_hang' || $orderby == 'khu_vuc') {
        $query->set('meta_key', '_' . $orderby);
        $query->set('orderby', 'meta_value');
    }
}
add_action('pre_get_posts', 'dnttvn_handle_doanh_nghiep_sorting');

// Add Admin Columns for Tin tức
function dnttvn_add_tin_tuc_admin_columns($columns) {
    $new_columns = array();
    $new_columns['cb'] = $columns['cb'];
    $new_columns['title'] = $columns['title'];
    $new_columns['menu_order'] = 'Thứ tự';
    $new_columns['noi_bat'] = 'Nổi bật';
    $new_columns['date'] = $columns['date'];
    return $new_columns;
}
add_filter('manage_tin_tuc_posts_columns', 'dnttvn_add_tin_tuc_admin_columns');

// Populate Admin Columns for Tin tức
function dnttvn_populate_tin_tuc_admin_columns($column, $post_id) {
    switch ($column) {
        case 'menu_order':
            $menu_order = get_post($post_id)->menu_order;
            echo '<strong>' . esc_html($menu_order) . '</strong>';
            break;
        case 'noi_bat':
            $noi_bat = get_post_meta($post_id, '_tin_tuc_noi_bat', true);
            if ($noi_bat == '1') {
                echo '<span style="color: #ff9800; font-weight: bold;">⭐ Nổi bật</span>';
            } else {
                echo '—';
            }
            break;
    }
}
add_action('manage_tin_tuc_posts_custom_column', 'dnttvn_populate_tin_tuc_admin_columns', 10, 2);

// Make Tin tức Columns Sortable
function dnttvn_make_tin_tuc_columns_sortable($columns) {
    $columns['menu_order'] = 'menu_order';
    $columns['noi_bat'] = 'noi_bat';
    return $columns;
}
add_filter('manage_edit-tin_tuc_sortable_columns', 'dnttvn_make_tin_tuc_columns_sortable');

// Enable drag & drop sorting for Tin tức
function dnttvn_enable_tin_tuc_drag_drop() {
    global $typenow;
    if ($typenow == 'tin_tuc') {
        wp_enqueue_script('jquery-ui-sortable');
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('#the-list').sortable({
                items: 'tr',
                cursor: 'move',
                handle: '.column-title',
                placeholder: 'ui-sortable-placeholder',
                update: function(event, ui) {
                    var order = [];
                    $('#the-list tr').each(function() {
                        var postId = $(this).attr('id').replace('post-', '');
                        order.push(postId);
                    });

                    // Save new order via AJAX
                    $.post(ajaxurl, {
                        action: 'update_tin_tuc_order',
                        order: order,
                        nonce: '<?php echo wp_create_nonce('update_tin_tuc_order'); ?>'
                    });
                }
            });

            // Add drag handle styling
            $('#the-list .column-title').css('cursor', 'move');
        });
        </script>
        <style>
            #the-list tr.ui-sortable-placeholder {
                background: #f0f0f0;
                border: 2px dashed #ccc;
                visibility: visible !important;
            }
            #the-list tr.ui-sortable-helper {
                background: #fff;
                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            }
        </style>
        <?php
    }
}
add_action('admin_footer', 'dnttvn_enable_tin_tuc_drag_drop');

// AJAX handler for updating tin tức order
function dnttvn_update_tin_tuc_order() {
    if (!wp_verify_nonce($_POST['nonce'], 'update_tin_tuc_order')) {
        wp_die('Security check failed');
    }

    if (!current_user_can('edit_posts')) {
        wp_die('Insufficient permissions');
    }

    $order = $_POST['order'];
    $position = 1;

    foreach ($order as $post_id) {
        wp_update_post(array(
            'ID' => $post_id,
            'menu_order' => $position
        ));
        $position++;
    }

    wp_die();
}
add_action('wp_ajax_update_tin_tuc_order', 'dnttvn_update_tin_tuc_order');

// Handle Tin tức Sorting
function dnttvn_handle_tin_tuc_sorting($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $orderby = $query->get('orderby');
    if ($orderby == 'menu_order') {
        $query->set('orderby', 'menu_order');
        $query->set('order', 'ASC');
    } elseif ($orderby == 'noi_bat') {
        $query->set('meta_key', '_tin_tuc_noi_bat');
        $query->set('orderby', 'meta_value date');
        $query->set('order', 'DESC');
    }
}
add_action('pre_get_posts', 'dnttvn_handle_tin_tuc_sorting');

// Add Admin Filters (Dropdown filters)
function dnttvn_add_doanh_nghiep_admin_filters() {
    global $typenow;
    
    if ($typenow == 'doanh_nghiep') {
        // Filter by Ngành hàng taxonomy
        $selected_nganh_hang = isset($_GET['nganh_hang_filter']) ? $_GET['nganh_hang_filter'] : '';
        $nganh_hang_terms = get_terms(array(
            'taxonomy' => 'nganh_hang',
            'hide_empty' => false,
        ));
        
        if (!empty($nganh_hang_terms) && !is_wp_error($nganh_hang_terms)) {
            echo '<select name="nganh_hang_filter">';
            echo '<option value="">Tất cả Ngành hàng</option>';
            foreach ($nganh_hang_terms as $term) {
                echo '<option value="' . esc_attr($term->slug) . '" ' . selected($selected_nganh_hang, $term->slug, false) . '>' . esc_html($term->name) . '</option>';
            }
            echo '</select>';
        }
        
        // Filter by Khu vực taxonomy
        $selected_khu_vuc = isset($_GET['khu_vuc_filter']) ? $_GET['khu_vuc_filter'] : '';
        $khu_vuc_terms = get_terms(array(
            'taxonomy' => 'khu_vuc',
            'hide_empty' => false,
        ));
        
        if (!empty($khu_vuc_terms) && !is_wp_error($khu_vuc_terms)) {
            echo '<select name="khu_vuc_filter">';
            echo '<option value="">Tất cả Khu vực</option>';
            foreach ($khu_vuc_terms as $term) {
                echo '<option value="' . esc_attr($term->slug) . '" ' . selected($selected_khu_vuc, $term->slug, false) . '>' . esc_html($term->name) . '</option>';
            }
            echo '</select>';
        }
    }
}
add_action('restrict_manage_posts', 'dnttvn_add_doanh_nghiep_admin_filters');

// Apply Admin Filters
function dnttvn_apply_doanh_nghiep_admin_filters($query) {
    global $pagenow, $typenow;
    
    if ($pagenow == 'edit.php' && $typenow == 'doanh_nghiep') {
        $tax_query = array();
        
        if (isset($_GET['nganh_hang_filter']) && $_GET['nganh_hang_filter'] != '') {
            $tax_query[] = array(
                'taxonomy' => 'nganh_hang',
                'field' => 'slug',
                'terms' => sanitize_text_field($_GET['nganh_hang_filter']),
            );
        }
        
        if (isset($_GET['khu_vuc_filter']) && $_GET['khu_vuc_filter'] != '') {
            $tax_query[] = array(
                'taxonomy' => 'khu_vuc',
                'field' => 'slug',
                'terms' => sanitize_text_field($_GET['khu_vuc_filter']),
            );
        }
        
        if (!empty($tax_query)) {
            $query->set('tax_query', $tax_query);
        }
    }
}
add_action('parse_query', 'dnttvn_apply_doanh_nghiep_admin_filters');

// Add Quick Edit Fields
function dnttvn_add_quick_edit_fields($column_name, $post_type) {
    if ($post_type != 'doanh_nghiep') {
        return;
    }
    ?>
    <fieldset class="inline-edit-col-right">
        <div class="inline-edit-col">
            <div class="inline-edit-group wp-clearfix">
                <label class="inline-edit-status alignleft">
                    <span class="title">Ngành hàng</span>
                    <input type="text" name="nganh_hang" value="" />
                </label>
            </div>
            <div class="inline-edit-group wp-clearfix">
                <label class="inline-edit-status alignleft">
                    <span class="title">Khu vực</span>
                    <input type="text" name="khu_vuc" value="" />
                </label>
            </div>
        </div>
    </fieldset>
    <?php
}
add_action('quick_edit_custom_box', 'dnttvn_add_quick_edit_fields', 10, 2);

// Save Quick Edit Data
function dnttvn_save_quick_edit_data($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (get_post_type($post_id) != 'doanh_nghiep') {
        return;
    }
    
    if (isset($_POST['nganh_hang'])) {
        update_post_meta($post_id, '_nganh_hang', sanitize_text_field($_POST['nganh_hang']));
    }
    
    if (isset($_POST['khu_vuc'])) {
        update_post_meta($post_id, '_khu_vuc', sanitize_text_field($_POST['khu_vuc']));
    }
}
add_action('save_post', 'dnttvn_save_quick_edit_data');

// Add Bulk Edit Fields
function dnttvn_add_bulk_edit_fields() {
    global $post_type;
    
    if ($post_type == 'doanh_nghiep') {
        ?>
        <div class="inline-edit-group">
            <label class="alignleft">
                <span class="title">Ngành hàng</span>
                <input type="text" name="_nganh_hang" value="" />
            </label>
        </div>
        <div class="inline-edit-group">
            <label class="alignleft">
                <span class="title">Khu vực</span>
                <input type="text" name="_khu_vuc" value="" />
            </label>
        </div>
        <?php
    }
}
add_action('bulk_edit_custom_box', 'dnttvn_add_bulk_edit_fields', 10, 2);

// Save Bulk Edit Data
function dnttvn_save_bulk_edit_data($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (get_post_type($post_id) != 'doanh_nghiep') {
        return;
    }
    
    // Check if this is bulk edit
    if (isset($_REQUEST['_inline_edit']) || isset($_REQUEST['bulk_edit'])) {
        if (isset($_REQUEST['_nganh_hang']) && $_REQUEST['_nganh_hang'] != '') {
            update_post_meta($post_id, '_nganh_hang', sanitize_text_field($_REQUEST['_nganh_hang']));
        }
        
        if (isset($_REQUEST['_khu_vuc']) && $_REQUEST['_khu_vuc'] != '') {
            update_post_meta($post_id, '_khu_vuc', sanitize_text_field($_REQUEST['_khu_vuc']));
        }
    }
}
add_action('save_post', 'dnttvn_save_bulk_edit_data');

// Enqueue Admin Scripts for Media Uploader
function dnttvn_enqueue_admin_scripts($hook) {
    global $post_type;
    
    if ($hook == 'post.php' || $hook == 'post-new.php') {
        if ($post_type == 'doanh_nghiep') {
            wp_enqueue_media();
            wp_enqueue_script('dnttvn-admin-script', get_template_directory_uri() . '/assets/admin-script.js', array('jquery'), '1.0.0', true);
        }
        
        // Enable full editor for Tin tức
        if ($post_type == 'tin_tuc') {
            wp_enqueue_media();
        }
    }
}
add_action('admin_enqueue_scripts', 'dnttvn_enqueue_admin_scripts');

// Add Dashboard Widgets
function dnttvn_add_dashboard_widgets() {
    wp_add_dashboard_widget(
        'dnttvn_stats_widget',
        'Thống kê Cộng đồng',
        'dnttvn_dashboard_stats_widget'
    );
}
add_action('wp_dashboard_setup', 'dnttvn_add_dashboard_widgets');

// Dashboard Stats Widget
function dnttvn_dashboard_stats_widget() {
    $tin_tuc_count = wp_count_posts('tin_tuc');
    $doanh_nghiep_count = wp_count_posts('doanh_nghiep');
    
    $nganh_hang_count = wp_count_terms(array('taxonomy' => 'nganh_hang', 'hide_empty' => false));
    $khu_vuc_count = wp_count_terms(array('taxonomy' => 'khu_vuc', 'hide_empty' => false));
    
    if (is_wp_error($nganh_hang_count)) {
        $nganh_hang_count = 0;
    }
    if (is_wp_error($khu_vuc_count)) {
        $khu_vuc_count = 0;
    }
    
    ?>
    <div style="padding: 10px;">
        <h3>Tin tức</h3>
        <ul>
            <li>Đã xuất bản: <strong><?php echo number_format_i18n($tin_tuc_count->publish); ?></strong></li>
            <li>Bản nháp: <strong><?php echo number_format_i18n($tin_tuc_count->draft); ?></strong></li>
            <li>Trong thùng rác: <strong><?php echo number_format_i18n($tin_tuc_count->trash); ?></strong></li>
        </ul>
        
        <h3>Doanh nghiệp</h3>
        <ul>
            <li>Đã xuất bản: <strong><?php echo number_format_i18n($doanh_nghiep_count->publish); ?></strong></li>
            <li>Bản nháp: <strong><?php echo number_format_i18n($doanh_nghiep_count->draft); ?></strong></li>
            <li>Trong thùng rác: <strong><?php echo number_format_i18n($doanh_nghiep_count->trash); ?></strong></li>
        </ul>
        
        <h3>Phân loại</h3>
        <ul>
            <li>Ngành hàng: <strong><?php echo number_format_i18n($nganh_hang_count); ?></strong></li>
            <li>Khu vực: <strong><?php echo number_format_i18n($khu_vuc_count); ?></strong></li>
        </ul>
        
        <p style="margin-top: 15px;">
            <a href="<?php echo admin_url('edit.php?post_type=tin_tuc'); ?>" class="button">Quản lý Tin tức</a>
            <a href="<?php echo admin_url('edit.php?post_type=doanh_nghiep'); ?>" class="button">Quản lý Doanh nghiệp</a>
        </p>
    </div>
    <?php
}

// Custom Pagination Function for Doanh nghiệp page
function dnttvn_custom_pagination($query = null) {
    global $wp_query;
    
    if (!$query) {
        $query = $wp_query;
    }
    
    $big = 999999999; // Need an unlikely integer
    $total_pages = $query->max_num_pages;
    
    if ($total_pages <= 1) {
        return '';
    }
    
    // Get current page
    // For custom page templates, check multiple sources
    $current_page = 1;
    if (get_query_var('paged')) {
        $current_page = get_query_var('paged');
    } elseif (get_query_var('page')) {
        $current_page = get_query_var('page');
    } elseif (isset($_GET['paged']) && is_numeric($_GET['paged'])) {
        $current_page = absint($_GET['paged']);
    }
    $current_page = max(1, $current_page);
    
    // Build query string to preserve search, filter, and sort parameters
    $query_args = array();
    if (isset($_GET['ten_doanh_nghiep']) && !empty($_GET['ten_doanh_nghiep'])) {
        $query_args['ten_doanh_nghiep'] = sanitize_text_field($_GET['ten_doanh_nghiep']);
    }
    if (isset($_GET['khu_vuc']) && !empty($_GET['khu_vuc'])) {
        $query_args['khu_vuc'] = sanitize_text_field($_GET['khu_vuc']);
    }
    if (isset($_GET['nganh_hang']) && !empty($_GET['nganh_hang'])) {
        $query_args['nganh_hang'] = sanitize_text_field($_GET['nganh_hang']);
    }
    if (isset($_GET['sort_by']) && !empty($_GET['sort_by'])) {
        $query_args['sort_by'] = sanitize_text_field($_GET['sort_by']);
    }
    
    // For custom page templates, use get_permalink() instead of get_pagenum_link()
    global $post;
    $page_permalink = '';
    if (is_page() && isset($post)) {
        $page_permalink = get_permalink($post->ID);
    } else {
        // Fallback to get_pagenum_link for archive pages
        $page_permalink = get_pagenum_link($big);
    }
    
    // Build base URL for pagination
    $base = str_replace($big, '%#%', esc_url($page_permalink));
    
    // Add query args to base URL
    if (!empty($query_args)) {
        $base = add_query_arg($query_args, $base);
    }
    
    // Ensure base ends with proper format
    if (strpos($base, '%#%') === false) {
        $base = trailingslashit($base) . '%#%';
    }
    
    $pagination = paginate_links(array(
        'base'      => $base,
        'format'    => '?paged=%#%',
        'current'   => $current_page,
        'total'     => $total_pages,
        'prev_text' => '&laquo; Trước',
        'next_text' => 'Sau &raquo;',
        'type'      => 'list',
        'end_size'  => 2,
        'mid_size'  => 2,
    ));
    
    return '<div class="pagination">' . $pagination . '</div>';
}

// Helper function to render banner blocks (for reuse in sidebar and mobile)
function dnttvn_render_banner_blocks($class_prefix = 'ad-block') {
    // Get banner order
    $banner_column_order = get_option('dnttvn_banner_column_order', 'vvip,vip,standard');
    $order_array = array_map('trim', explode(',', $banner_column_order));

    // Prepare banner data with order preservation
    $banner_data = array(
        'vvip' => array(
            'banners' => get_option('dnttvn_vvip_banners', array()),
            'links' => get_option('dnttvn_vvip_links', array()),
            'type' => 'vvip',
            'title' => 'Video quảng cáo hoặc banner: VVIP',
            'label' => 'VVIP'
        ),
        'vip' => array(
            'banners' => get_option('dnttvn_vip_banners', array()),
            'links' => get_option('dnttvn_vip_links', array()),
            'type' => 'vip',
            'title' => 'Video quảng cáo hoặc banner: VIP',
            'label' => 'VIP'
        ),
        'standard' => array(
            'banners' => get_option('dnttvn_standard_banners', array()),
            'links' => get_option('dnttvn_standard_links', array()),
            'type' => 'standard',
            'title' => 'Video quảng cáo hoặc banner: Standard',
            'label' => 'Standard'
        )
    );

    $output = '';

    // Display banners according to order
    foreach ($order_array as $banner_type) {
        if (!isset($banner_data[$banner_type])) continue;

        $data = $banner_data[$banner_type];
        $banners = $data['banners'];
        $links = $data['links'];

        if (!empty($banners)) {
            // Display banners in their saved order
            foreach ($banners as $index => $banner_id) {
                if ($banner_id) {
                    $banner_url = wp_get_attachment_image_url($banner_id, 'full');
                    $banner_alt = get_post_meta($banner_id, '_wp_attachment_image_alt', true);
                    $link_url = isset($links[$index]) ? $links[$index] : '';
                    if ($banner_url) {
                        $output .= '<div class="' . esc_attr($class_prefix) . ' ' . esc_attr($data['type']) . '">';
                        $output .= '<h4>' . esc_html($data['title']) . '</h4>';
                        $output .= '<div class="ad-type">' . esc_html($data['label']) . '</div>';
                        $output .= '<div class="ad-description">Blog 15 giây, tối đa 5 doanh nghiệp</div>';
                        if ($link_url) {
                            $output .= '<a href="' . esc_url($link_url) . '" target="_blank">';
                        }
                        $mime_type = get_post_mime_type($banner_id);
                        if (strpos($mime_type, 'video') !== false) {
                            $output .= '<video src="' . esc_url($banner_url) . '" controls style="width: 100%; max-width: 100%;"></video>';
                        } else {
                            $output .= '<img src="' . esc_url($banner_url) . '" alt="' . esc_attr($banner_alt) . '" style="width: 100%; max-width: 100%;">';
                        }
                        if ($link_url) {
                            $output .= '</a>';
                        }
                        $output .= '</div>';
                    }
                }
            }
        }
    }

    return $output;
}

// ============================================
// SOCIAL MEDIA LINKS MANAGEMENT
// ============================================

/**
 * Register Social Media Links Admin Menu
 */
function dnttvn_social_links_admin_menu() {
    add_menu_page(
        'Social Media Links',           // Page title
        'Social Media',                 // Menu title
        'manage_options',               // Capability
        'dnttvn-social-links',          // Menu slug
        'dnttvn_social_links_settings_page', // Callback function
        'dashicons-share',              // Icon
        80                              // Position
    );
}
add_action('admin_menu', 'dnttvn_social_links_admin_menu');

/**
 * Register Settings
 */
function dnttvn_register_social_links_settings() {
    // Register settings
    register_setting('dnttvn_social_links_group', 'dnttvn_facebook_url', array(
        'sanitize_callback' => 'dnttvn_validate_social_url',
        'default' => ''
    ));
    register_setting('dnttvn_social_links_group', 'dnttvn_tiktok_url', array(
        'sanitize_callback' => 'dnttvn_validate_social_url',
        'default' => ''
    ));
    register_setting('dnttvn_social_links_group', 'dnttvn_zalo_url', array(
        'sanitize_callback' => 'dnttvn_validate_social_url',
        'default' => ''
    ));
    register_setting('dnttvn_social_links_group', 'dnttvn_youtube_url', array(
        'sanitize_callback' => 'dnttvn_validate_social_url',
        'default' => ''
    ));
    
    // Add settings section
    add_settings_section(
        'dnttvn_social_links_section',
        'Cấu hình liên kết Social Media',
        'dnttvn_social_links_section_callback',
        'dnttvn-social-links'
    );
    
    // Add settings fields
    add_settings_field(
        'dnttvn_facebook_url',
        '<span class="dashicons dashicons-facebook" style="color: #1877f2;"></span> Facebook URL',
        'dnttvn_facebook_url_callback',
        'dnttvn-social-links',
        'dnttvn_social_links_section'
    );
    
    add_settings_field(
        'dnttvn_tiktok_url',
        '<span class="dashicons dashicons-video-alt3" style="color: #000;"></span> TikTok URL',
        'dnttvn_tiktok_url_callback',
        'dnttvn-social-links',
        'dnttvn_social_links_section'
    );
    
    add_settings_field(
        'dnttvn_zalo_url',
        '<span class="dashicons dashicons-format-chat" style="color: #0068ff;"></span> Zalo URL',
        'dnttvn_zalo_url_callback',
        'dnttvn-social-links',
        'dnttvn_social_links_section'
    );
    
    add_settings_field(
        'dnttvn_youtube_url',
        '<span class="dashicons dashicons-video-alt2" style="color: #ff0000;"></span> YouTube URL',
        'dnttvn_youtube_url_callback',
        'dnttvn-social-links',
        'dnttvn_social_links_section'
    );
}
add_action('admin_init', 'dnttvn_register_social_links_settings');

/**
 * Section Callback
 */
function dnttvn_social_links_section_callback() {
    echo '<p>Nhập URL đầy đủ cho các trang social media của bạn. Ví dụ: <code>https://facebook.com/yourpage</code></p>';
    echo '<p>Nếu để trống, nút tương ứng sẽ không hiển thị trên website.</p>';
}

/**
 * Field Callbacks
 */
function dnttvn_facebook_url_callback() {
    $value = get_option('dnttvn_facebook_url', '');
    echo '<input type="url" name="dnttvn_facebook_url" value="' . esc_attr($value) . '" class="regular-text" placeholder="https://facebook.com/yourpage">';
    echo '<p class="description">Nhập URL trang Facebook của bạn</p>';
}

function dnttvn_tiktok_url_callback() {
    $value = get_option('dnttvn_tiktok_url', '');
    echo '<input type="url" name="dnttvn_tiktok_url" value="' . esc_attr($value) . '" class="regular-text" placeholder="https://tiktok.com/@yourpage">';
    echo '<p class="description">Nhập URL trang TikTok của bạn</p>';
}

function dnttvn_zalo_url_callback() {
    $value = get_option('dnttvn_zalo_url', '');
    echo '<input type="url" name="dnttvn_zalo_url" value="' . esc_attr($value) . '" class="regular-text" placeholder="https://zalo.me/yourpage">';
    echo '<p class="description">Nhập URL Zalo của bạn</p>';
}

function dnttvn_youtube_url_callback() {
    $value = get_option('dnttvn_youtube_url', '');
    echo '<input type="url" name="dnttvn_youtube_url" value="' . esc_attr($value) . '" class="regular-text" placeholder="https://youtube.com/@yourchannel">';
    echo '<p class="description">Nhập URL kênh YouTube của bạn</p>';
}

/**
 * Validate URL
 */
function dnttvn_validate_social_url($url) {
    // If empty, allow it
    if (empty($url)) {
        return '';
    }
    
    // Validate URL format
    $url = trim($url);
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        add_settings_error(
            'dnttvn_social_links',
            'invalid_url',
            'URL không hợp lệ. Vui lòng nhập URL đầy đủ (ví dụ: https://facebook.com/yourpage)',
            'error'
        );
        return '';
    }
    
    return esc_url_raw($url);
}

/**
 * Settings Page HTML
 */
function dnttvn_social_links_settings_page() {
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Show success message after save
    if (isset($_GET['settings-updated'])) {
        add_settings_error(
            'dnttvn_social_links_messages',
            'dnttvn_social_links_message',
            'Cài đặt đã được lưu thành công!',
            'updated'
        );
    }
    
    settings_errors('dnttvn_social_links_messages');
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2>Quản lý liên kết Social Media</h2>
            <p>Cấu hình các liên kết social media sẽ hiển thị ở phần header của website.</p>
            
            <form action="options.php" method="post">
                <?php
                settings_fields('dnttvn_social_links_group');
                do_settings_sections('dnttvn-social-links');
                submit_button('Lưu cài đặt');
                ?>
            </form>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h3>Preview</h3>
            <p>Các link hiện tại:</p>
            <ul style="list-style: none; padding: 0;">
                <?php
                $facebook = get_option('dnttvn_facebook_url', '');
                $tiktok = get_option('dnttvn_tiktok_url', '');
                $zalo = get_option('dnttvn_zalo_url', '');
                $youtube = get_option('dnttvn_youtube_url', '');
                ?>
                <li style="padding: 8px 0; border-bottom: 1px solid #ddd;">
                    <span class="dashicons dashicons-facebook" style="color: #1877f2;"></span>
                    <strong>Facebook:</strong> 
                    <?php echo $facebook ? '<a href="' . esc_url($facebook) . '" target="_blank">' . esc_html($facebook) . '</a>' : '<em style="color: #999;">Chưa cấu hình</em>'; ?>
                </li>
                <li style="padding: 8px 0; border-bottom: 1px solid #ddd;">
                    <span class="dashicons dashicons-video-alt3"></span>
                    <strong>TikTok:</strong> 
                    <?php echo $tiktok ? '<a href="' . esc_url($tiktok) . '" target="_blank">' . esc_html($tiktok) . '</a>' : '<em style="color: #999;">Chưa cấu hình</em>'; ?>
                </li>
                <li style="padding: 8px 0; border-bottom: 1px solid #ddd;">
                    <span class="dashicons dashicons-format-chat" style="color: #0068ff;"></span>
                    <strong>Zalo:</strong> 
                    <?php echo $zalo ? '<a href="' . esc_url($zalo) . '" target="_blank">' . esc_html($zalo) . '</a>' : '<em style="color: #999;">Chưa cấu hình</em>'; ?>
                </li>
                <li style="padding: 8px 0;">
                    <span class="dashicons dashicons-video-alt2" style="color: #ff0000;"></span>
                    <strong>YouTube:</strong> 
                    <?php echo $youtube ? '<a href="' . esc_url($youtube) . '" target="_blank">' . esc_html($youtube) . '</a>' : '<em style="color: #999;">Chưa cấu hình</em>'; ?>
                </li>
            </ul>
        </div>
        
        <div class="card" style="max-width: 800px; margin-top: 20px; background: #f0f6fc; border-left: 4px solid #0073aa;">
            <h3 style="margin-top: 0;">💡 Hướng dẫn</h3>
            <ol style="line-height: 1.8;">
                <li>Nhập URL đầy đủ cho mỗi platform (bắt đầu với https://)</li>
                <li>Nếu không muốn hiển thị nút nào, để trống field đó</li>
                <li>Click "Lưu cài đặt" để cập nhật</li>
                <li>Kiểm tra header website để xem các nút social media</li>
            </ol>
            <p><strong>Lưu ý:</strong> Sau khi lưu, các link sẽ tự động hiển thị ở phần "KÊNH LIÊN KẾT" trên header của website.</p>
        </div>
    </div>
    <style>
        .card {
            background: #fff;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
            padding: 20px;
        }
        .card h2, .card h3 {
            margin-top: 0;
        }
    </style>
    <?php
}


// Add Custom Fields to Search
function dnttvn_extend_admin_search($search, $wp_query) {
    global $wpdb;
    
    if (!is_admin() || !$wp_query->is_search() || !isset($wp_query->query_vars['post_type']) || $wp_query->query_vars['post_type'] != 'doanh_nghiep') {
        return $search;
    }
    
    $search_term = $wp_query->query_vars['s'];
    $search = " AND (
        {$wpdb->posts}.post_title LIKE '%" . esc_sql($wpdb->esc_like($search_term)) . "%'
        OR {$wpdb->posts}.post_content LIKE '%" . esc_sql($wpdb->esc_like($search_term)) . "%'
        OR EXISTS (
            SELECT 1 FROM {$wpdb->postmeta}
            WHERE {$wpdb->postmeta}.post_id = {$wpdb->posts}.ID
            AND (
                {$wpdb->postmeta}.meta_key = '_nganh_hang'
                OR {$wpdb->postmeta}.meta_key = '_khu_vuc'
            )
            AND {$wpdb->postmeta}.meta_value LIKE '%" . esc_sql($wpdb->esc_like($search_term)) . "%'
        )
    )";
    
    return $search;
}
add_filter('posts_search', 'dnttvn_extend_admin_search', 10, 2);

// ============================================
// BANNER MANAGEMENT
// ============================================

// Register Customizer for Header Banners
function dnttvn_customize_register($wp_customize) {
    // Add Section for Header Banners
    $wp_customize->add_section('dnttvn_header_banners', array(
        'title'    => 'Banner Header',
        'priority' => 30,
    ));
    
    // Banner 1
    $wp_customize->add_setting('dnttvn_banner_1', array(
        'default'           => '',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'dnttvn_banner_1', array(
        'label'     => 'Banner 1',
        'section'   => 'dnttvn_header_banners',
        'mime_type' => 'image',
    )));
    
    // Banner 2
    $wp_customize->add_setting('dnttvn_banner_2', array(
        'default'           => '',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'dnttvn_banner_2', array(
        'label'     => 'Banner 2',
        'section'   => 'dnttvn_header_banners',
        'mime_type' => 'image',
    )));
    
    // Banner 3
    $wp_customize->add_setting('dnttvn_banner_3', array(
        'default'           => '',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'dnttvn_banner_3', array(
        'label'     => 'Banner 3',
        'section'   => 'dnttvn_header_banners',
        'mime_type' => 'image',
    )));
    
    // Banner 4
    $wp_customize->add_setting('dnttvn_banner_4', array(
        'default'           => '',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'dnttvn_banner_4', array(
        'label'     => 'Banner 4',
        'section'   => 'dnttvn_header_banners',
        'mime_type' => 'image',
    )));
    
    // Banner 5
    $wp_customize->add_setting('dnttvn_banner_5', array(
        'default'           => '',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'dnttvn_banner_5', array(
        'label'     => 'Banner 5',
        'section'   => 'dnttvn_header_banners',
        'mime_type' => 'image',
    )));
    
    // Banner Order (Thứ tự hiển thị)
    $wp_customize->add_setting('dnttvn_banner_order', array(
        'default'           => '1,2,3,4,5',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('dnttvn_banner_order', array(
        'label'       => 'Thứ tự hiển thị Banner',
        'section'     => 'dnttvn_header_banners',
        'type'        => 'text',
        'description' => 'Nhập thứ tự banner (ví dụ: 1,2,3,4,5 hoặc 5,4,3,2,1). Phân cách bằng dấu phẩy.',
    ));
}
add_action('customize_register', 'dnttvn_customize_register');

// Create Admin Settings Page for Ad Blocks
function dnttvn_add_admin_menu() {
    add_menu_page(
        'Quản lý Banner',
        'Quản lý Banner',
        'manage_options',
        'dnttvn-banner-settings',
        'dnttvn_banner_settings_page',
        'dashicons-images-alt2',
        30
    );
}
add_action('admin_menu', 'dnttvn_add_admin_menu');

// Banner Settings Page
function dnttvn_banner_settings_page() {
    // Xử lý lưu dữ liệu khi bấm các nút Lưu (tổng hoặc từng ô)
    $has_save_action =
        isset($_POST['dnttvn_save_banners']) ||
        isset($_POST['dnttvn_save_banner_header']) ||
        isset($_POST['dnttvn_save_banner_vvip']) ||
        isset($_POST['dnttvn_save_banner_vip']) ||
        isset($_POST['dnttvn_save_banner_standard']);

    if ($has_save_action && check_admin_referer('dnttvn_save_banners_action', 'dnttvn_save_banners_nonce')) {
        $is_global      = isset($_POST['dnttvn_save_banners']);
        $save_header    = $is_global || isset($_POST['dnttvn_save_banner_header']);
        $save_vvip      = $is_global || isset($_POST['dnttvn_save_banner_vvip']);
        $save_vip       = $is_global || isset($_POST['dnttvn_save_banner_vip']);
        $save_standard  = $is_global || isset($_POST['dnttvn_save_banner_standard']);

        // Save Header Banners (for header slider)
        if ($save_header) {
            if (isset($_POST['header_banners']) && is_array($_POST['header_banners'])) {
                for ($i = 1; $i <= 5; $i++) {
                    $banner_id = isset($_POST['header_banners'][$i]) ? absint($_POST['header_banners'][$i]) : 0;
                    set_theme_mod('dnttvn_banner_' . $i, $banner_id);
                }
            }
            if (isset($_POST['header_banner_order'])) {
                set_theme_mod('dnttvn_banner_order', sanitize_text_field($_POST['header_banner_order']));
            }
        }
        
        // Save VVIP Ad Blocks - Support unlimited banners
        if ($save_vvip) {
            $vvip_banners = isset($_POST['vvip_banners']) ? $_POST['vvip_banners'] : array();
            $vvip_links = isset($_POST['vvip_links']) ? $_POST['vvip_links'] : array();

            // Filter out empty banners
            $filtered_vvip_banners = array();
            $filtered_vvip_links = array();

            foreach ($vvip_banners as $index => $banner_id) {
                if (!empty($banner_id)) {
                    $filtered_vvip_banners[] = absint($banner_id);
                    $filtered_vvip_links[] = isset($vvip_links[$index]) ? esc_url_raw($vvip_links[$index]) : '';
                }
            }

            update_option('dnttvn_vvip_banners', $filtered_vvip_banners);
            update_option('dnttvn_vvip_links', $filtered_vvip_links);
        }

        // Save VIP Ad Blocks - Support unlimited banners
        if ($save_vip) {
            $vip_banners = isset($_POST['vip_banners']) ? $_POST['vip_banners'] : array();
            $vip_links = isset($_POST['vip_links']) ? $_POST['vip_links'] : array();

            // Filter out empty banners
            $filtered_vip_banners = array();
            $filtered_vip_links = array();

            foreach ($vip_banners as $index => $banner_id) {
                if (!empty($banner_id)) {
                    $filtered_vip_banners[] = absint($banner_id);
                    $filtered_vip_links[] = isset($vip_links[$index]) ? esc_url_raw($vip_links[$index]) : '';
                }
            }

            update_option('dnttvn_vip_banners', $filtered_vip_banners);
            update_option('dnttvn_vip_links', $filtered_vip_links);
        }

        // Save Standard Ad Blocks - Support unlimited banners
        if ($save_standard) {
            $standard_banners = isset($_POST['standard_banners']) ? $_POST['standard_banners'] : array();
            $standard_links = isset($_POST['standard_links']) ? $_POST['standard_links'] : array();

            // Filter out empty banners
            $filtered_standard_banners = array();
            $filtered_standard_links = array();

            foreach ($standard_banners as $index => $banner_id) {
                if (!empty($banner_id)) {
                    $filtered_standard_banners[] = absint($banner_id);
                    $filtered_standard_links[] = isset($standard_links[$index]) ? esc_url_raw($standard_links[$index]) : '';
                }
            }

            update_option('dnttvn_standard_banners', $filtered_standard_banners);
            update_option('dnttvn_standard_links', $filtered_standard_links);
        }
        
        // Save Banner Order (Thứ tự hiển thị cột phải)
        if ($is_global && isset($_POST['banner_column_order'])) {
            update_option('dnttvn_banner_column_order', sanitize_text_field($_POST['banner_column_order']));
        }
        
        echo '<div class="notice notice-success"><p>Đã lưu banner thành công!</p></div>';
    }
    
    // Header banners (for header slider)
    $header_banners = array();
    for ($i = 1; $i <= 5; $i++) {
        $header_banners[$i] = get_theme_mod('dnttvn_banner_' . $i, '');
    }
    $header_banner_order = get_theme_mod('dnttvn_banner_order', '1,2,3,4,5');
    
    $banner_column_order = get_option('dnttvn_banner_column_order', 'vvip,vip,standard');
    
    $vvip_banners = get_option('dnttvn_vvip_banners', array());
    $vvip_links = get_option('dnttvn_vvip_links', array());
    $vip_banners = get_option('dnttvn_vip_banners', array());
    $vip_links = get_option('dnttvn_vip_links', array());
    $standard_banners = get_option('dnttvn_standard_banners', array());
    $standard_links = get_option('dnttvn_standard_links', array());
    
    wp_enqueue_media();
    ?>
    <div class="wrap">
        <h1>Quản lý Banner & Video Quảng cáo</h1>
        <p class="description">Quản lý banner và video quảng cáo hiển thị ở cột bên phải trang "Danh sách Doanh nghiệp". Hỗ trợ cả hình ảnh và video.</p>
        <form method="post" action="">
            <?php wp_nonce_field('dnttvn_save_banners_action', 'dnttvn_save_banners_nonce'); ?>
            
            <h2>Banner Header (Slider trên đầu trang)</h2>
            <p class="description">Chọn tối đa 5 banner để hiển thị trong slider ở phần đầu trang (Header). Thứ tự hiển thị có thể thay đổi bên dưới.</p>
            <div id="header-banners-container">
                <?php
                for ($i = 1; $i <= 5; $i++) {
                    $banner_id = isset($header_banners[$i]) ? $header_banners[$i] : '';
                    ?>
                    <div class="banner-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd;">
                        <h3>Banner Header <?php echo $i; ?></h3>
                        <p>
                            <label><strong>Hình ảnh Banner Header <?php echo $i; ?>:</strong></label><br>
                            <input type="hidden" name="header_banners[<?php echo $i; ?>]" class="banner-image-id" value="<?php echo esc_attr($banner_id); ?>">
                            <button type="button" class="button button-primary upload-banner-btn" data-type="header" data-index="<?php echo $i; ?>">📁 Chọn hình ảnh</button>
                            <button type="button" class="button remove-banner-btn" data-type="header" data-index="<?php echo $i; ?>">🗑️ Xóa</button>
                            <span class="description" style="margin-left: 10px;">Khuyến nghị: kích thước ngang, định dạng JPG/PNG.</span>
                        </p>
                        <div class="banner-preview" style="margin-top: 10px;">
                            <?php
                            if ($banner_id) {
                                echo wp_get_attachment_image($banner_id, 'medium');
                            }
                            ?>
                        </div>
                        <p>
                            <button type="submit" name="dnttvn_save_banner_header" value="<?php echo $i; ?>" class="button button-secondary">Lưu Banner Header <?php echo $i; ?></button>
                        </p>
                    </div>
                    <?php
                }
                ?>
            </div>
            
            <h3>Thứ tự hiển thị Banner Header</h3>
            <p>
                <label for="header_banner_order"><strong>Thứ tự banner:</strong></label><br>
                <input type="text" id="header_banner_order" name="header_banner_order" value="<?php echo esc_attr($header_banner_order); ?>" class="regular-text" />
            </p>
            <p class="description">Nhập thứ tự banner theo số (1–5), phân cách bằng dấu phẩy. Ví dụ: <code>1,2,3,4,5</code> hoặc <code>5,4,3,2,1</code>.</p>
            
            <h2>Banner VVIP (Tối đa 2 banner)</h2>
            <div id="vvip-banners-container" class="banners-sortable">
                <?php
                $vvip_count = max(1, count($vvip_banners));
                for ($i = 0; $i < $vvip_count; $i++) {
                    $banner_id = isset($vvip_banners[$i]) ? $vvip_banners[$i] : '';
                    $banner_url = isset($vvip_links[$i]) ? $vvip_links[$i] : '';
                    ?>
                    <div class="banner-item sortable-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; background: #f9f9f9; position: relative;">
                        <div class="banner-handle" style="cursor: move; background: #e1e1e1; padding: 8px; margin: -15px -15px 15px -15px; border-bottom: 1px solid #ddd;">
                            <span style="font-weight: bold; color: #333;">⋮⋮ Banner VVIP <?php echo $i + 1; ?> ⋮⋮</span>
                            <button type="button" class="button remove-banner-btn" style="float: right; background: #dc3232; color: white; border: none; padding: 2px 8px;">×</button>
                        </div>
                        <div style="padding: 10px;">
                            <p>
                                <label><strong>Hình ảnh/Video Quảng cáo:</strong></label><br>
                                <input type="hidden" name="vvip_banners[]" class="banner-image-id" value="<?php echo esc_attr($banner_id); ?>">
                                <button type="button" class="button button-primary upload-banner-btn" data-type="vvip" data-index="<?php echo $i; ?>">📁 Chọn hình ảnh/Video</button>
                                <span class="description" style="margin-left: 10px;">Hỗ trợ: JPG, PNG, GIF, MP4, WebM</span>
                            </p>
                            <div class="banner-preview" style="margin-top: 10px;">
                                <?php if ($banner_id) :
                                    $mime_type = get_post_mime_type($banner_id);
                                    if (strpos($mime_type, 'video') !== false) :
                                        $video_url = wp_get_attachment_url($banner_id);
                                        ?>
                                        <video src="<?php echo esc_url($video_url); ?>" controls style="max-width: 300px; max-height: 200px; display: block; margin-top: 10px;"></video>
                                        <p style="margin-top: 5px; color: #666; font-size: 12px;">Video ID: <?php echo esc_html($banner_id); ?></p>
                                    <?php else :
                                        echo wp_get_attachment_image($banner_id, 'medium');
                                    endif;
                                endif; ?>
                            </div>
                            <p>
                                <label>Link (nếu có):</label><br>
                                <input type="url" name="vvip_links[]" value="<?php echo esc_attr($banner_url); ?>" class="regular-text" placeholder="https://...">
                            </p>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div style="margin-bottom: 20px; text-align: center;">
                    <button type="button" class="button button-secondary add-banner-btn" data-type="vvip">➕ Thêm Banner VVIP</button>
                </div>
            </div>
            
            <h2>Banner VIP</h2>
            <div id="vip-banners-container" class="banners-sortable">
                <?php
                $vip_count = max(1, count($vip_banners));
                for ($i = 0; $i < $vip_count; $i++) {
                    $banner_id = isset($vip_banners[$i]) ? $vip_banners[$i] : '';
                    $banner_url = isset($vip_links[$i]) ? $vip_links[$i] : '';
                    ?>
                    <div class="banner-item sortable-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; background: #f9f9f9; position: relative;">
                        <div class="banner-handle" style="cursor: move; background: #e1e1e1; padding: 8px; margin: -15px -15px 15px -15px; border-bottom: 1px solid #ddd;">
                            <span style="font-weight: bold; color: #333;">⋮⋮ Banner VIP <?php echo $i + 1; ?> ⋮⋮</span>
                            <button type="button" class="button remove-banner-btn" style="float: right; background: #dc3232; color: white; border: none; padding: 2px 8px;">×</button>
                        </div>
                        <div style="padding: 10px;">
                            <p>
                                <label><strong>Hình ảnh/Video Quảng cáo:</strong></label><br>
                                <input type="hidden" name="vip_banners[]" class="banner-image-id" value="<?php echo esc_attr($banner_id); ?>">
                                <button type="button" class="button button-primary upload-banner-btn" data-type="vip" data-index="<?php echo $i; ?>">📁 Chọn hình ảnh/Video</button>
                                <span class="description" style="margin-left: 10px;">Hỗ trợ: JPG, PNG, GIF, MP4, WebM</span>
                            </p>
                            <div class="banner-preview" style="margin-top: 10px;">
                                <?php if ($banner_id) :
                                    $mime_type = get_post_mime_type($banner_id);
                                    if (strpos($mime_type, 'video') !== false) :
                                        $video_url = wp_get_attachment_url($banner_id);
                                        ?>
                                        <video src="<?php echo esc_url($video_url); ?>" controls style="max-width: 300px; max-height: 200px; display: block; margin-top: 10px;"></video>
                                        <p style="margin-top: 5px; color: #666; font-size: 12px;">Video ID: <?php echo esc_html($banner_id); ?></p>
                                    <?php else :
                                        echo wp_get_attachment_image($banner_id, 'medium');
                                    endif;
                                endif; ?>
                            </div>
                            <p>
                                <label>Link (nếu có):</label><br>
                                <input type="url" name="vip_links[]" value="<?php echo esc_attr($banner_url); ?>" class="regular-text" placeholder="https://...">
                            </p>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div style="margin-bottom: 20px; text-align: center;">
                    <button type="button" class="button button-secondary add-banner-btn" data-type="vip">➕ Thêm Banner VIP</button>
                </div>
            </div>
            
            <h2>Banner Standard</h2>
            <div id="standard-banners-container" class="banners-sortable">
                <?php
                $standard_count = max(1, count($standard_banners));
                for ($i = 0; $i < $standard_count; $i++) {
                    $banner_id = isset($standard_banners[$i]) ? $standard_banners[$i] : '';
                    $banner_url = isset($standard_links[$i]) ? $standard_links[$i] : '';
                    ?>
                    <div class="banner-item sortable-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; background: #f9f9f9; position: relative;">
                        <div class="banner-handle" style="cursor: move; background: #e1e1e1; padding: 8px; margin: -15px -15px 15px -15px; border-bottom: 1px solid #ddd;">
                            <span style="font-weight: bold; color: #333;">⋮⋮ Banner Standard <?php echo $i + 1; ?> ⋮⋮</span>
                            <button type="button" class="button remove-banner-btn" style="float: right; background: #dc3232; color: white; border: none; padding: 2px 8px;">×</button>
                        </div>
                        <div style="padding: 10px;">
                            <p>
                                <label><strong>Hình ảnh/Video Quảng cáo:</strong></label><br>
                                <input type="hidden" name="standard_banners[]" class="banner-image-id" value="<?php echo esc_attr($banner_id); ?>">
                                <button type="button" class="button button-primary upload-banner-btn" data-type="standard" data-index="<?php echo $i; ?>">📁 Chọn hình ảnh/Video</button>
                                <span class="description" style="margin-left: 10px;">Hỗ trợ: JPG, PNG, GIF, MP4, WebM</span>
                            </p>
                            <div class="banner-preview" style="margin-top: 10px;">
                                <?php if ($banner_id) :
                                    $mime_type = get_post_mime_type($banner_id);
                                    if (strpos($mime_type, 'video') !== false) :
                                        $video_url = wp_get_attachment_url($banner_id);
                                        ?>
                                        <video src="<?php echo esc_url($video_url); ?>" controls style="max-width: 300px; max-height: 200px; display: block; margin-top: 10px;"></video>
                                        <p style="margin-top: 5px; color: #666; font-size: 12px;">Video ID: <?php echo esc_html($banner_id); ?></p>
                                    <?php else :
                                        echo wp_get_attachment_image($banner_id, 'medium');
                                    endif;
                                endif; ?>
                            </div>
                            <p>
                                <label>Link (nếu có):</label><br>
                                <input type="url" name="standard_links[]" value="<?php echo esc_attr($banner_url); ?>" class="regular-text" placeholder="https://...">
                            </p>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div style="margin-bottom: 20px; text-align: center;">
                    <button type="button" class="button button-secondary add-banner-btn" data-type="standard">➕ Thêm Banner Standard</button>
                </div>
            </div>
            
            <h2 style="margin-top: 40px;">Thứ tự hiển thị Banner</h2>
            <div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 20px;">
                <p>
                    <label for="banner_column_order"><strong>Thứ tự hiển thị các loại banner:</strong></label><br>
                    <select name="banner_column_order" id="banner_column_order" style="min-width: 300px; padding: 8px;">
                        <option value="vvip,vip,standard" <?php selected($banner_column_order, 'vvip,vip,standard'); ?>>VVIP → VIP → Standard</option>
                        <option value="vvip,standard,vip" <?php selected($banner_column_order, 'vvip,standard,vip'); ?>>VVIP → Standard → VIP</option>
                        <option value="vip,vvip,standard" <?php selected($banner_column_order, 'vip,vvip,standard'); ?>>VIP → VVIP → Standard</option>
                        <option value="vip,standard,vvip" <?php selected($banner_column_order, 'vip,standard,vvip'); ?>>VIP → Standard → VVIP</option>
                        <option value="standard,vvip,vip" <?php selected($banner_column_order, 'standard,vvip,vip'); ?>>Standard → VVIP → VIP</option>
                        <option value="standard,vip,vvip" <?php selected($banner_column_order, 'standard,vip,vvip'); ?>>Standard → VIP → VVIP</option>
                    </select>
                </p>
                <p class="description">Chọn thứ tự hiển thị các loại banner ở cột bên phải trang doanh nghiệp.</p>
            </div>
            
            <p class="submit">
                <input type="submit" name="dnttvn_save_banners" class="button button-primary" value="Lưu Banner">
            </p>
        </form>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        var mediaUploader;

        // Initialize sortable for banner containers
        $('.banners-sortable').sortable({
            handle: '.banner-handle',
            placeholder: 'sortable-placeholder',
            update: function(event, ui) {
                updateBannerNumbers();
            }
        });

        // Upload banner button
        $(document).on('click', '.upload-banner-btn', function(e) {
            e.preventDefault();
            var button = $(this);
            var container = button.closest('.banner-item');
            var input = container.find('.banner-image-id');
            var preview = container.find('.banner-preview');

            if (mediaUploader) {
                mediaUploader.open();
                return;
            }

            mediaUploader = wp.media({
                title: 'Chọn Banner',
                button: {
                    text: 'Sử dụng hình ảnh này'
                },
                multiple: false,
                library: {
                    type: ['image', 'video']
                }
            });

            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                input.val(attachment.id);
                var previewHtml = '';
                if (attachment.type === 'image') {
                    previewHtml = '<img src="' + attachment.url + '" style="max-width: 300px; max-height: 200px; display: block; margin-top: 10px;">';
                    previewHtml += '<p style="margin-top: 5px; color: #666; font-size: 12px;">Hình ảnh ID: ' + attachment.id + '</p>';
                } else if (attachment.type === 'video') {
                    previewHtml = '<video src="' + attachment.url + '" controls style="max-width: 300px; max-height: 200px; display: block; margin-top: 10px;"></video>';
                    previewHtml += '<p style="margin-top: 5px; color: #666; font-size: 12px;">Video ID: ' + attachment.id + ' (' + attachment.mime + ')</p>';
                }
                preview.html(previewHtml);
            });

            mediaUploader.open();
        });

        // Remove banner button
        $(document).on('click', '.remove-banner-btn', function(e) {
            e.preventDefault();
            var container = $(this).closest('.banner-item');
            container.find('.banner-image-id').val('');
            container.find('.banner-preview').html('');
            container.find('input[type="url"]').val('');
        });

        // Add new banner button
        $(document).on('click', '.add-banner-btn', function(e) {
            e.preventDefault();
            var button = $(this);
            var type = button.data('type');
            var container = $('#' + type + '-banners-container .sortable-item').last();

            // Clone the last banner item
            var newBanner = container.clone();

            // Clear values
            newBanner.find('.banner-image-id').val('');
            newBanner.find('.banner-preview').html('');
            newBanner.find('input[type="url"]').val('');

            // Update title
            var bannerCount = $('#' + type + '-banners-container .sortable-item').length + 1;
            newBanner.find('.banner-handle span').html('⋮⋮ Banner ' + type.toUpperCase() + ' ' + bannerCount + ' ⋮⋮');

            // Insert before the add button
            button.parent().before(newBanner);

            updateBannerNumbers();
        });

        // Function to update banner numbers after sorting or adding
        function updateBannerNumbers() {
            $('.banners-sortable').each(function() {
                var container = $(this);
                var type = container.attr('id').replace('-banners-container', '');
                var typeUpper = type.toUpperCase();

                container.find('.sortable-item').each(function(index) {
                    $(this).find('.banner-handle span').html('⋮⋮ Banner ' + typeUpper + ' ' + (index + 1) + ' ⋮⋮');
                });
            });
        }

        // Remove banner item completely
        $(document).on('click', '.sortable-item .remove-banner-btn', function(e) {
            e.preventDefault();
            if (confirm('Bạn có chắc muốn xóa banner này?')) {
                $(this).closest('.sortable-item').remove();
                updateBannerNumbers();
            }
        });
    });
    </script>

    <style>
        .sortable-placeholder {
            background: #f0f0f0;
            border: 2px dashed #ccc;
            margin-bottom: 20px;
            height: 50px;
        }
        .banners-sortable .sortable-item {
            cursor: move;
        }
        .banner-handle {
            transition: background-color 0.2s;
        }
        .banner-handle:hover {
            background: #d1d1d1 !important;
        }
        .remove-banner-btn {
            transition: background-color 0.2s;
        }
        .remove-banner-btn:hover {
            background: #c42c2c !important;
        }
    </style>
    <?php
}

// Enqueue admin script for banner management
function dnttvn_enqueue_banner_admin_scripts($hook) {
    if ($hook != 'toplevel_page_dnttvn-banner-settings') {
        return;
    }
    wp_enqueue_media();
}
add_action('admin_enqueue_scripts', 'dnttvn_enqueue_banner_admin_scripts');
