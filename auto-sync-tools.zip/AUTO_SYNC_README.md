# 🚀 TỰ ĐỘNG SYNC CODE SANG WORDPRESS LOCAL

## 🎯 MỤC TIÊU
Mỗi lần sửa code trong `wordpress-theme/`, tự động sync sang WordPress Local mà **KHÔNG cần chạy script thủ công!**

---

## ✅ CÁCH 1: SYMBOLIC LINK (KHUYẾN NGHỊ - TỰ ĐỘNG HOÀN TOÀN)

### Ưu điểm:
- ✅ **Tự động 100%** - Thay đổi ngay lập tức
- ✅ **Không cần script** - Không cần chạy gì thêm
- ✅ **Nhanh nhất** - Không mất thời gian sync

### Cách dùng:

#### Bước 1: Chuẩn bị
```powershell
# Đóng WordPress Local hoàn toàn
# (Đóng Local.app và tất cả browser tabs)
```

#### Bước 2: Chạy Script Setup
```powershell
# Mở PowerShell với quyền Administrator
# Right-click PowerShell → "Run as Administrator"

cd c:\Projects\Website
.\setup-symbolic-link.ps1
```

#### Bước 3: Kiểm tra
```powershell
# Mở WordPress Local trở lại
# Vào: http://test.local/

# Thay đổi bất kỳ file nào trong wordpress-theme/
# Refresh trang WordPress → Thấy thay đổi ngay lập tức!
```

### 🎉 Kết quả:
- **Trước**: Sửa code → Chạy `.\sync-to-local.ps1` → Refresh WordPress
- **Sau**: Sửa code → Refresh WordPress → Xong!

---

## 🔄 CÁCH 2: FILE WATCHER (TỰ ĐỘNG SYNC)

### Ưu điểm:
- ✅ **Tự động sync** khi có thay đổi
- ✅ **Không cần Administrator** quyền
- ✅ **Có thể customize** delay time

### Cách dùng:

#### Bước 1: Chạy Script Watcher
```powershell
cd c:\Projects\Website
.\auto-sync-watcher.ps1
```

#### Bước 2: Sửa code
- Sửa bất kỳ file nào trong `wordpress-theme/`
- Script sẽ tự động detect và sync sau 2 giây

#### Bước 3: Refresh WordPress
- Thấy thay đổi ngay lập tức!

### Tùy chỉnh:
```powershell
# Thay đổi delay time (giây)
.\auto-sync-watcher.ps1 -syncDelay 5

# Thay đổi đường dẫn
.\auto-sync-watcher.ps1 -sourcePath "c:\Projects\Website\wordpress-theme" -destPath "C:\Path\To\WordPress\Theme"
```

---

## 🛠️ CÁCH 3: VS CODE TASK (TÍCH HỢP IDE)

### Thêm vào `.vscode/tasks.json`:
```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Sync to WordPress Local",
            "type": "shell",
            "command": "powershell",
            "args": [
                "-ExecutionPolicy", "Bypass",
                "-File", "${workspaceFolder}/sync-to-local.ps1"
            ],
            "group": {
                "kind": "build",
                "isDefault": true
            },
            "presentation": {
                "echo": true,
                "reveal": "always",
                "focus": false,
                "panel": "shared"
            }
        }
    ]
}
```

### Cách dùng:
- **Ctrl+Shift+P** → "Tasks: Run Task"
- Chọn "Sync to WordPress Local"
- Hoặc **Ctrl+Shift+B** (default build task)

---

## 📋 SO SÁNH CÁC CÁCH

| Cách | Tự động | Cần Admin | Setup | Performance |
|------|---------|-----------|-------|-------------|
| **Symbolic Link** | 100% | ✅ Có | 1 lần | ⚡ Nhanh nhất |
| **File Watcher** | 99% | ❌ Không | 1 lần | 🚀 Rất nhanh |
| **VS Code Task** | Thủ công | ❌ Không | 1 lần | 🐌 Chậm hơn |

---

## 🚨 LƯU Ý QUAN TRỌNG

### Với Symbolic Link:
1. **Phải chạy PowerShell as Administrator**
2. **Đóng WordPress Local** trước khi setup
3. **Không thể xóa** thư mục theme cũ nếu WordPress đang chạy

### Với File Watcher:
1. **Để script chạy** trong background
2. **Ctrl+C** để dừng khi không cần
3. **Có thể customize** delay và đường dẫn

### Chung:
1. **Backup** theme cũ trước khi setup
2. **Test kỹ** sau khi setup
3. **Đường dẫn** phải chính xác

---

## 🔧 KHẮC PHỤC LỖI

### Lỗi "Access Denied":
```
# Đóng WordPress Local hoàn toàn
# Chạy PowerShell as Administrator
# Thử lại
```

### Lỗi "Path not found":
```
# Kiểm tra đường dẫn trong script
$sourcePath = "c:\Projects\Website\wordpress-theme"
$destPath = "C:\Users\Admin\Local Sites\test\app\public\wp-content\themes\test-theme"
```

### Lỗi Symbolic Link không hoạt động:
```
# Thử cách File Watcher thay thế
.\auto-sync-watcher.ps1
```

---

## 🎯 KHUYẾN NGHỊ

### **Dùng Symbolic Link nếu:**
- Muốn **tự động hoàn toàn**
- Có thể chạy **Administrator**
- WordPress Local ở **ổ C:**

### **Dùng File Watcher nếu:**
- **Không thể** chạy Administrator
- Muốn **customize** delay time
- Cần **control** quá trình sync

---

## 📞 HỖ TRỢ

Nếu gặp vấn đề:
1. **Kiểm tra** đường dẫn trong script
2. **Đóng** WordPress Local khi setup
3. **Chạy Administrator** PowerShell
4. **Test** bằng cách sửa 1 file và refresh

---

## ✅ CHECKLIST SETUP

### Symbolic Link:
- [ ] Đóng WordPress Local
- [ ] Mở PowerShell as Administrator
- [ ] Chạy `.\setup-symbolic-link.ps1`
- [ ] Mở WordPress Local
- [ ] Test bằng cách sửa file và refresh

### File Watcher:
- [ ] Chạy `.\auto-sync-watcher.ps1`
- [ ] Sửa file bất kỳ
- [ ] Kiểm tra console output
- [ ] Refresh WordPress

**Chúc mừng! Từ bây giờ không cần sync thủ công nữa! 🎉**