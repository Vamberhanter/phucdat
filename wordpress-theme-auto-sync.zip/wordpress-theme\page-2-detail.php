<?php
/**
 * Template Name: Chi tiết Doanh nghiệp
 * 
 * Template for displaying single business detail page
 * Based on website/page-gioi-thieu-standalone.html layout
 */

get_header();

// Lấy post_id từ query để hiển thị chi tiết tin tức hoặc doanh nghiệp
$detail_post   = null;
$detail_post_id = isset($_GET['post_id']) ? absint($_GET['post_id']) : 0;

if ($detail_post_id) {
    $detail_post = get_post($detail_post_id);
}
?>

<main class="main-content">
    <!-- Left Sidebar -->
    <div class="sidebar-column">
        <div class="column-header mobile-toggle collapsed">Về Cộng đồng DNTTVN</div>
        <div class="column-content mobile-collapsed">
            <ul class="about-list">
                <li><a href="#">Điều lệ tổ chức hoạt động</a></li>
                <li><a href="#">Danh sách thành viên sáng lập</a></li>
                <li><a href="#">Cấu trúc Cộng đồng</a></li>
                <li><a href="#">Danh sách Lãnh đạo điều hành</a></li>
                <li class="highlight-item">
                    <a href="#">Tìm hiểu trở thành thành viên mới</a>
                </li>
                <li><a href="#">Giá trị nhận được của thành viên</a></li>
                <li><a href="#">Quy trình gia nhập Cộng đồng</a></li>
                <li><a href="#">Hỏi đáp về Cộng đồng</a></li>
            </ul>
        </div>
    </div>

    <!-- Center Content -->
    <div class="main-center">
        <?php
        if ($detail_post && !is_wp_error($detail_post)) :
            setup_postdata($detail_post);
            $post_type = get_post_type($detail_post);

            // Nếu là doanh nghiệp: dùng layout business card
            if ($post_type === 'doanh_nghiep') :
            // Get custom fields
            $nganh_hang   = get_post_meta($detail_post_id, '_nganh_hang', true);
            $khu_vuc      = get_post_meta($detail_post_id, '_khu_vuc', true);
            $hinh_anh_phu = get_post_meta($detail_post_id, '_hinh_anh_phu', true);
            $gallery_raw  = get_post_meta($detail_post_id, '_gallery_images', true);
            $gallery_ids  = array_filter(array_map('absint', explode(',', (string) $gallery_raw)));
            $dia_chi      = get_post_meta($detail_post_id, '_dia_chi', true);
            $dien_thoai   = get_post_meta($detail_post_id, '_dien_thoai', true);
            $email_lh     = get_post_meta($detail_post_id, '_email_lien_he', true);
            $website_dn   = get_post_meta($detail_post_id, '_website_doanh_nghiep', true);
            $thong_tin_bs = get_post_meta($detail_post_id, '_thong_tin_bo_sung', true);
                
                // Get Featured Image (Hình chính)
                $featured_image_id  = get_post_thumbnail_id($detail_post_id);
                $featured_image_url = '';
                $featured_image_alt = '';
                if ($featured_image_id) {
                    $featured_image_url = wp_get_attachment_image_url($featured_image_id, 'full');
                    $featured_image_alt = get_post_meta($featured_image_id, '_wp_attachment_image_alt', true);
                    if (empty($featured_image_alt)) {
                        $featured_image_alt = get_the_title($detail_post_id) . ' - Logo';
                    }
                }
                
                // Get Hình ảnh phụ (Small image) - single fallback if no gallery
                $small_image_id  = null;
                $small_image_url = '';
                $small_image_alt = '';
                if (!$gallery_ids && $hinh_anh_phu) {
                    if (is_numeric($hinh_anh_phu)) {
                        $small_image_id = absint($hinh_anh_phu);
                    } else {
                        $small_image_id = attachment_url_to_postid($hinh_anh_phu);
                        if (!$small_image_id) {
                            $small_image_url = esc_url($hinh_anh_phu);
                        }
                    }
                    
                    if ($small_image_id) {
                        $small_image_url = wp_get_attachment_image_url($small_image_id, 'full');
                        $small_image_alt = get_post_meta($small_image_id, '_wp_attachment_image_alt', true);
                        if (empty($small_image_alt)) {
                            $small_image_alt = get_the_title($detail_post_id) . ' - Hình ảnh phụ';
                        }
                    }
                }
                
                // Get taxonomy terms
                $nganh_hang_terms = get_the_terms($detail_post_id, 'nganh_hang');
                $khu_vuc_terms    = get_the_terms($detail_post_id, 'khu_vuc');
                ?>
                <div class="business-card" style="max-width: 100%;">
                    <div class="business-card-left">
                        <!-- Hình chính (Featured Image) -->
                        <div class="business-card-image">
                            <?php if ($featured_image_url) : ?>
                                <img src="<?php echo esc_url($featured_image_url); ?>" 
                                     alt="<?php echo esc_attr($featured_image_alt); ?>" 
                                     class="business-main-image"
                                     loading="lazy">
                            <?php else : ?>
                                <img src="https://via.placeholder.com/200x200/667eea/ffffff?text=<?php echo esc_attr(urlencode(get_the_title($detail_post_id))); ?>" 
                                     alt="<?php echo esc_attr(get_the_title($detail_post_id)); ?>" 
                                     class="business-main-image"
                                     loading="lazy">
                            <?php endif; ?>
                        </div>
                        <div class="business-card-info-section">
                            <h4><?php echo esc_html(get_the_title($detail_post_id)); ?></h4>
                            
                            <?php if ($nganh_hang) : ?>
                                <div class="business-card-info">
                                    <svg class="business-card-info-icon" viewBox="0 0 24 24">
                                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                    </svg>
                                    <p><strong>Ngành hàng:</strong> <?php echo esc_html($nganh_hang); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($nganh_hang_terms && !is_wp_error($nganh_hang_terms)) : ?>
                                <div class="business-card-info">
                                    <svg class="business-card-info-icon" viewBox="0 0 24 24">
                                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                    </svg>
                                    <p><strong>Ngành hàng (Taxonomy):</strong> 
                                        <?php
                                        $term_names = array();
                                        foreach ($nganh_hang_terms as $term) {
                                            $term_names[] = '<a href="' . esc_url(get_term_link($term)) . '">' . esc_html($term->name) . '</a>';
                                        }
                                        echo implode(', ', $term_names);
                                        ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($khu_vuc) : ?>
                                <div class="business-card-info">
                                    <svg class="business-card-info-icon" viewBox="0 0 24 24">
                                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                                    </svg>
                                    <p><strong>Khu vực:</strong> <?php echo esc_html($khu_vuc); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($khu_vuc_terms && !is_wp_error($khu_vuc_terms)) : ?>
                                <div class="business-card-info">
                                    <svg class="business-card-info-icon" viewBox="0 0 24 24">
                                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                                    </svg>
                                    <p><strong>Khu vực (Taxonomy):</strong> 
                                        <?php
                                        $term_names = array();
                                        foreach ($khu_vuc_terms as $term) {
                                            $term_names[] = '<a href="' . esc_url(get_term_link($term)) . '">' . esc_html($term->name) . '</a>';
                                        }
                                        echo implode(', ', $term_names);
                                        ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                            
                            <p style="margin-top: 15px; color: #666; font-size: 14px;">
                                <strong>Ngày đăng:</strong> <?php echo get_the_date('d/m/Y', $detail_post_id); ?>
                            </p>
                        </div>
                    </div>
                <div class="business-card-content">
                    <!-- Hình ảnh phụ / Thư viện hình -->
                    <?php if ($gallery_ids) : ?>
                        <div class="business-card-small-image">
                            <div class="business-card-small-image-slider">
                                <?php
                                $first = true;
                                foreach ($gallery_ids as $img_id) :
                                    $img_url = wp_get_attachment_image_url($img_id, 'large');
                                    if (!$img_url) {
                                        continue;
                                    }
                                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
                                    if (empty($img_alt)) {
                                        $img_alt = get_the_title($detail_post_id) . ' - Hình ảnh ' . $img_id;
                                    }
                                    ?>
                                    <div class="business-card-small-image-slide <?php echo $first ? 'active' : ''; ?>">
                                        <img src="<?php echo esc_url($img_url); ?>" 
                                             alt="<?php echo esc_attr($img_alt); ?>" 
                                             class="business-small-image"
                                             loading="lazy">
                                    </div>
                                    <?php
                                    $first = false;
                                endforeach;
                                ?>
                            </div>
                            <div class="business-card-small-image-nav">
                                <button type="button" class="business-card-small-image-prev">&#10094;</button>
                                <button type="button" class="business-card-small-image-next">&#10095;</button>
                            </div>
                        </div>
                    <?php elseif ($small_image_url || ($small_image_id && $small_image_url)) : ?>
                        <div class="business-card-small-image">
                            <?php if ($small_image_id) : ?>
                                <img src="<?php echo esc_url($small_image_url); ?>" 
                                     alt="<?php echo esc_attr($small_image_alt); ?>" 
                                     class="business-small-image"
                                     loading="lazy">
                            <?php else : ?>
                                <img src="<?php echo esc_url($small_image_url); ?>" 
                                     alt="<?php echo esc_attr(get_the_title($detail_post_id) . ' - Hình ảnh phụ'); ?>" 
                                     class="business-small-image"
                                     loading="lazy">
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                        
                        <!-- Mô tả doanh nghiệp -->
                        <div class="business-card-description" style="font-size: 16px; line-height: 1.8;">
                            <h3 style="margin-top:0; margin-bottom:10px; font-size:18px; color:#06202e;">Mô tả chi tiết doanh nghiệp</h3>
                            <?php echo apply_filters('the_content', $detail_post->post_content); ?>
                        </div>

                        <!-- Thông tin bổ sung -->
                        <?php if ($dia_chi || $dien_thoai || $email_lh || $website_dn || $thong_tin_bs) : ?>
                            <div style="margin-top: 25px; padding: 15px 18px; border-radius: 8px; background:#f8f9fa; border:1px solid #e0e0e0;">
                                <h3 style="margin-top:0; margin-bottom:12px; font-size:18px; color:#06202e;">Thông tin bổ sung</h3>
                                <ul style="list-style:none; margin:0; padding:0; font-size:14px; color:#444;">
                                    <?php if ($dia_chi) : ?>
                                        <li style="margin-bottom:6px;"><strong>Địa chỉ:</strong> <?php echo esc_html($dia_chi); ?></li>
                                    <?php endif; ?>
                                    <?php if ($dien_thoai) : ?>
                                        <li style="margin-bottom:6px;"><strong>Điện thoại:</strong> <?php echo esc_html($dien_thoai); ?></li>
                                    <?php endif; ?>
                                    <?php if ($email_lh) : ?>
                                        <li style="margin-bottom:6px;"><strong>Email:</strong> <a href="mailto:<?php echo esc_attr($email_lh); ?>"><?php echo esc_html($email_lh); ?></a></li>
                                    <?php endif; ?>
                                    <?php if ($website_dn) : ?>
                                        <li style="margin-bottom:6px;"><strong>Website:</strong> <a href="<?php echo esc_url($website_dn); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($website_dn); ?></a></li>
                                    <?php endif; ?>
                                </ul>
                                <?php if ($thong_tin_bs) : ?>
                                    <div style="margin-top:10px; font-size:14px; color:#555; line-height:1.7;">
                                        <?php echo wp_kses_post(wpautop($thong_tin_bs)); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php
            
            // Nếu là tin tức: dùng layout tin tức chi tiết
            elseif ($post_type === 'tin_tuc') :
                ?>
                <div class="content-column">
                    <div class="column-header"><?php echo esc_html(get_the_title($detail_post_id)); ?></div>
                    <div class="column-content">
                        <div class="news-item">
                            <p class="news-date">
                                <strong>Ngày đăng:</strong> <?php echo get_the_date('d/m/Y', $detail_post_id); ?>
                                <?php 
                                $tac_gia = get_post_meta($detail_post_id, '_tin_tuc_tac_gia', true);
                                if ($tac_gia) {
                                    echo ' | <strong>Tác giả:</strong> ' . esc_html($tac_gia);
                                }
                                $nguon = get_post_meta($detail_post_id, '_tin_tuc_nguon', true);
                                if ($nguon) {
                                    echo ' | <strong>Nguồn:</strong> <a href="' . esc_url($nguon) . '" target="_blank">Xem nguồn</a>';
                                }
                                ?>
                            </p>
                            
                            <?php if (has_post_thumbnail($detail_post_id)) : ?>
                                <div style="margin-bottom: 20px; text-align: center;">
                                    <?php echo get_the_post_thumbnail($detail_post_id, 'large', array('style' => 'max-width: 100%; height: auto; border-radius: 8px;')); ?>
                                </div>
                            <?php endif; ?>
                            
                            <div style="line-height: 1.8; font-size: 16px;">
                                <?php echo apply_filters('the_content', $detail_post->post_content); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            
            // Các loại post khác: hiển thị đơn giản
            else :
                ?>
                <div class="content-column">
                    <div class="column-header"><?php echo esc_html(get_the_title($detail_post_id)); ?></div>
                    <div class="column-content">
                        <div class="news-item">
                            <div style="line-height: 1.8; font-size: 16px;">
                                <?php echo apply_filters('the_content', $detail_post->post_content); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            endif;

            wp_reset_postdata();
        else :
            ?>
            <div class="content-column">
                <div class="column-header">Không tìm thấy nội dung</div>
                <div class="column-content">
                    <p>Không tìm thấy Tin tức hoặc Doanh nghiệp tương ứng. Vui lòng kiểm tra lại liên kết.</p>
                </div>
            </div>
            <?php
        endif;
        ?>
    </div>

    <!-- Right Sidebar -->
    <div class="sidebar-column">
        <div class="column-header mobile-toggle collapsed">Theo ngành hàng</div>
        <div class="column-content mobile-collapsed">
            <div class="ad-section">
                <?php echo dnttvn_render_banner_blocks('ad-block'); ?>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
