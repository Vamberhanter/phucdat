<?php
/**
 * Single Post Template for Cộng đồng
 */

get_header();
?>

<main class="main-content">
    <!-- Left Sidebar -->
    <div class="sidebar-column">
        <div class="column-header mobile-toggle collapsed">Về Cộng đồng DNTTVN</div>
        <div class="column-content mobile-collapsed">
            <ul class="about-list">
                <?php
                // Query Cộng đồng posts for sidebar
                $sidebar_args = array(
                    'post_type'      => 'cong_dong',
                    'posts_per_page' => -1,
                    'post_status'    => 'publish',
                    'orderby'        => 'menu_order date',
                    'order'          => 'ASC',
                );
                $sidebar_query = new WP_Query($sidebar_args);
                
                // Get current post ID
                $current_post_id = get_the_ID();
                
                if ($sidebar_query->have_posts()) :
                    while ($sidebar_query->have_posts()) : $sidebar_query->the_post();
                        $post_id = get_the_ID();
                        $is_noi_bat = get_post_meta($post_id, '_cong_dong_noi_bat', true);
                        $li_class = ($is_noi_bat == '1') ? 'highlight-item' : '';
                        
                        // Highlight current item
                        if ($current_post_id == $post_id) {
                            $li_class .= ' current-item';
                        }
                        ?>
                        <li class="<?php echo esc_attr(trim($li_class)); ?>">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </li>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                    ?>
                    <li><a href="#">Chưa có bài viết Cộng đồng</a></li>
                    <?php
                endif;
                ?>
            </ul>
        </div>
    </div>

    <!-- Center Content -->
    <div class="main-center">
        <div class="content-column">
            <div class="column-header">Bài viết Cộng đồng</div>
            
            <div class="column-content">
                <?php
                while (have_posts()) : the_post();
                    ?>
                    <article class="cong-dong-detail" style="padding: 0;">
                        <h2><?php the_title(); ?></h2>
                        <p class="news-date"><?php echo get_the_date('d/m/Y'); ?></p>
                        
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="featured-image" style="margin: 20px 0;">
                                <?php the_post_thumbnail('large', array('style' => 'max-width: 100%; height: auto; border-radius: 4px;')); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="article-content" style="margin-top: 20px; line-height: 1.8;">
                            <?php the_content(); ?>
                        </div>
                        
                        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
                            <?php 
                            $cong_dong_page = get_page_by_path('cong-dong');
                            $cong_dong_page_url = $cong_dong_page ? get_permalink($cong_dong_page->ID) : home_url('/cong-dong/');
                            ?>
                            <a href="<?php echo esc_url($cong_dong_page_url); ?>" class="button">← Quay lại danh sách</a>
                        </div>
                    </article>
                    <?php
                endwhile;
                ?>
            </div>
        </div>
    </div>

    <!-- Right Sidebar -->
    <div class="sidebar-column">
        <div class="column-header mobile-toggle collapsed">Website liên kết</div>
        <div class="column-content mobile-collapsed">
            <h4 style="margin-bottom: 15px; color: #333;">Danh sách Doanh nghiệp</h4>
            <ul class="linked-websites">
                <?php
                // Get page link for "Danh sách Doanh nghiệp"
                $page_doanh_nghiep = get_page_by_path('danh-sach-doanh-nghiep');
                if (!$page_doanh_nghiep) {
                    $page_doanh_nghiep = get_page_by_path('page-doanh-nghiep');
                }
                if ($page_doanh_nghiep) {
                    $doanh_nghiep_page_url = get_permalink($page_doanh_nghiep->ID);
                } else {
                    $doanh_nghiep_page_url = home_url('/danh-sach-doanh-nghiep/');
                }
                ?>
                <li><a href="<?php echo esc_url($doanh_nghiep_page_url); ?>">Danh sách Doanh nghiệp</a></li>
                <?php
                $doanh_nghiep_args = array(
                    'post_type'      => 'doanh_nghiep',
                    'posts_per_page' => 4,
                    'post_status'    => 'publish',
                );
                $doanh_nghiep_query = new WP_Query($doanh_nghiep_args);
                
                // Detail page for doanh_nghiep
                $detail_page      = get_page_by_path('trang-doanh-nghiep-chi-tiet');
                $detail_page_base = $detail_page ? get_permalink($detail_page->ID) : home_url('/trang-doanh-nghiep-chi-tiet/');

                if ($doanh_nghiep_query->have_posts()) :
                    while ($doanh_nghiep_query->have_posts()) : $doanh_nghiep_query->the_post();
                        // For Doanh nghiep, we might be using the special detail page with query param as per previous code
                        $detail_url = add_query_arg('post_id', get_the_ID(), $detail_page_base);
                        ?>
                        <li><a href="<?php echo esc_url($detail_url); ?>"><?php the_title(); ?></a></li>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </ul>
            <h4 style="margin-top: 25px; margin-bottom: 15px; color: #333;">Cộng đồng</h4>
            <ul class="linked-websites">
                <li><a href="<?php echo esc_url($cong_dong_page_url); ?>">Trang Cộng đồng</a></li>
                <li><a href="#">Cộng đồng Doanh nhân Trẻ</a></li>
                <li><a href="#">Cộng đồng Khởi nghiệp</a></li>
                <li><a href="#">Cộng đồng Đầu tư</a></li>
            </ul>
        </div>
    </div>
</main>

<style>
    .current-item {
        background-color: #f0f0f0;
        font-weight: bold;
    }
    
    .current-item a {
        color: #2271b1 !important;
    }
    
    .cong-dong-detail h2 {
        color: #333;
        margin-bottom: 10px;
    }
    
    .button {
        display: inline-block;
        background: #2271b1;
        color: #fff;
        padding: 8px 15px;
        text-decoration: none;
        border-radius: 4px;
        transition: background 0.3s;
        font-size: 14px;
    }
    
    .button:hover {
        background: #135e96;
    }
</style>

<?php get_footer(); ?>
