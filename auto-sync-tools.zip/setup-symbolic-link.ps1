# Script tao Symbolic Link cho WordPress Local
# Sau khi chay script nay, moi thay doi se TU DONG sync

Write-Host "=== TAO SYMBOLIC LINK CHO WORDPRESS LOCAL ===" -ForegroundColor Cyan
Write-Host "Script nay se tao lien ket tu dong giua thu muc project va WordPress Local" -ForegroundColor Yellow
Write-Host ""

# Cau hinh duong dan
$sourcePath = "c:\Projects\Website\wordpress-theme"
$destPath = "C:\Users\Admin\Local Sites\test\app\public\wp-content\themes\test-theme"

Write-Host "Nguon: $sourcePath" -ForegroundColor Green
Write-Host "Dich:  $destPath" -ForegroundColor Green
Write-Host ""

# Kiem tra thu muc nguon
if (-not (Test-Path $sourcePath)) {
    Write-Host "LOI: Khong tim thay thu muc nguon: $sourcePath" -ForegroundColor Red
    exit 1
}

# Kiem tra va xoa thu muc theme cu neu co
$themeDir = Split-Path $destPath -Parent
$themeName = Split-Path $destPath -Leaf

if (Test-Path $destPath) {
    Write-Host "Dang xoa thu muc theme cu..." -ForegroundColor Yellow
    try {
        Remove-Item $destPath -Recurse -Force
        Write-Host "Da xoa thu muc cu thanh cong!" -ForegroundColor Green
    } catch {
        Write-Host "LOI: Khong the xoa thu muc cu. Vui long dong WordPress Local va thu lai!" -ForegroundColor Red
        exit 1
    }
}

# Tao thu muc cha neu chua co
if (-not (Test-Path $themeDir)) {
    New-Item -ItemType Directory -Path $themeDir -Force | Out-Null
}

# Tao Symbolic Link
Write-Host "Dang tao Symbolic Link..." -ForegroundColor Yellow
try {
    New-Item -ItemType SymbolicLink -Path $destPath -Target $sourcePath -Force
    Write-Host "THANH CONG! Symbolic Link da duoc tao." -ForegroundColor Green
    Write-Host ""
    Write-Host "TU BAY GIO, MOI THAY DOI TRONG:" -ForegroundColor Cyan
    Write-Host "  $sourcePath" -ForegroundColor White
    Write-Host "SE TU DONG HIEN THI TRONG:" -ForegroundColor Cyan
    Write-Host "  $destPath" -ForegroundColor White
    Write-Host ""
    Write-Host "KHONG CAN CHAY SYNC NUA!" -ForegroundColor Green
    Write-Host "CHI CAN REFRESH TRANG WORDPRESS!" -ForegroundColor Yellow
} catch {
    Write-Host "LOI: Khong the tao Symbolic Link. Vui long chay PowerShell voi quyen Administrator!" -ForegroundColor Red
    Write-Host "Lenh: Right-click PowerShell -> 'Run as Administrator'" -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "=== HOAN THANH ===" -ForegroundColor Green
Write-Host "Vui long refresh trang WordPress de test!" -ForegroundColor Cyan